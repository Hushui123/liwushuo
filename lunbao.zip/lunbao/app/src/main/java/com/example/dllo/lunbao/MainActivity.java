package com.example.dllo.lunbao;

import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Gallery main_gallery;
    LinearLayout main_lin;

    List<Object> li;

    Integer[] res = {R.mipmap.photo1, R.mipmap.photo2, R.mipmap.photo3, R.mipmap.photo4, R.mipmap.photo5};

    Gallery_adapter gallery_adapter;

    int current_circle = 0;

    Runnable timeadv;
    int count;

    Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initview();
        li = new ArrayList<Object>();
        for(int i = 0;i<res.length;i++){
            li.add(res[i]);
        }

        gallery_adapter = new Gallery_adapter(this);

        main_gallery.setAdapter(gallery_adapter);
        gallery_adapter.setList(li);
        setCircle();

        main_gallery.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "toast", Toast.LENGTH_SHORT).show();
            }
        });
        //设置滚动图片的时候，对应小圆点的图片切换
        main_gallery.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                View v = main_lin.getChildAt(position);
                View cuview = main_lin.getChildAt(current_circle);

                if(v != null && cuview != null){
                    ImageView pointView = (ImageView) v;
                    ImageView curpointView = (ImageView) cuview;
                    curpointView
                            .setBackgroundResource(R.mipmap.icon_heart_unselected);
                    pointView
                            .setBackgroundResource(R.mipmap.icon_heart_selected);
                    current_circle = position;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //设置轮播定时器
        timeadv = new Runnable() {

            @Override
            public void run() {
                //获取当前的图片是哪一张图片，图片的序号，
                count = main_gallery.getSelectedItemPosition();
                //当前滚动的图片序号大于多有的图片的数量，就跳转到第一张图片，否则就跳转到下一张图片
                if(count+1>=li.size()){
                    count = 0;
                }else{
                    count = count+1;
                }
                main_gallery.setSelection(count);
                handler.postDelayed(this, 1000);

            }
        };

        //开启定时器，1000毫秒切换一次图片
        handler.postDelayed(timeadv, 1000);
    }

    private void initview() {
        main_gallery = (Gallery) this.findViewById(R.id.main_gallery);
        main_lin = (LinearLayout) this.findViewById(R.id.main_lin);

    }

    //设置滚动图片的小圆点
    private void setCircle() {
        for(int i = 0;i<li.size();i++){
            ImageView iv = new ImageView(MainActivity.this);
            //循环创建小圆点，判断第一个小圆点为白色的，其他的都是透明的
            if(i == 0){
                iv.setBackgroundResource(R.mipmap.icon_heart_selected);
            }else{
                iv.setBackgroundResource(R.mipmap.icon_heart_unselected);
            }
            main_lin.addView(iv);

            //设置小圆点的margin值
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, 1);
            lp.setMargins(5, 10, 5, 10);
            iv.setLayoutParams(lp);
        }
    }

    @Override
    public void onDestroy() {
        //关闭activity时，关闭定时器
        if(handler != null){
            //判断定时器时候为null，！null就销毁
            if(timeadv != null){
                handler.removeCallbacks(timeadv);
            }
        }
        super.onDestroy();
    }
}
