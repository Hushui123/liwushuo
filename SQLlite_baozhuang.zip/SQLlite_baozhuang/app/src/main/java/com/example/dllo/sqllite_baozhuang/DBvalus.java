package com.example.dllo.sqllite_baozhuang;

/**
 * Created by dllo on 16/8/25.
 */
public class DBvalus {

    public static String table_name="student";
    public static String TABLE_STUDENT_NAME="name";
    public static String TABLE_STUDENT_AGE="age";
    public static String SQL_NAME="Person.db";

}
