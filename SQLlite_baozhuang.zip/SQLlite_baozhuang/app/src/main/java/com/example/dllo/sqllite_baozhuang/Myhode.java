package com.example.dllo.sqllite_baozhuang;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dllo on 16/8/25.
 */
public class Myhode extends SQLiteOpenHelper{
    public Myhode(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table "+DBvalus.table_name+"(id integer primary key" +
                " autoincrement,"+DBvalus.TABLE_STUDENT_NAME+" text," +
                ""+DBvalus.TABLE_STUDENT_AGE+" text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
