package com.example.dllo.sqllite_baozhuang;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by dllo on 16/8/25.
 */
public class DETpose {
    private SQLiteDatabase database;

    public DETpose(MainActivity activity) {
        Myhode hlper=new Myhode(activity,DBvalus.SQL_NAME,null,1);
        database = hlper.getWritableDatabase();
    }

    public void insert(){


            Student student=new Student();
            student.setName("lala");
            student.setNum(18);
            ContentValues values=new ContentValues();
            values.put(DBvalus.TABLE_STUDENT_NAME,"dada");
            values.put(DBvalus.TABLE_STUDENT_AGE,15);

            database.insert(DBvalus.table_name,null,values);

    }
    public void delete(){
        database.delete(DBvalus.table_name,null,null);

    }
    public void deleteof(String whereClasse,String[] wherearg){
        database.delete(DBvalus.table_name, whereClasse+"=?", wherearg);

    }

    /**
     *
     * @param bean   想要修改后的数据
     * @param whereClasse   想要修改的列名
     * @param wherearg  想要修改的条件
     */
    public void update(Student bean,String whereClasse,String[] wherearg){
        ContentValues values=new ContentValues();
        values.put(DBvalus.TABLE_STUDENT_NAME,bean.getName());
        values.put(DBvalus.TABLE_STUDENT_AGE,bean.getNum());

        database.update(DBvalus.table_name,values,whereClasse+"=?",wherearg);
    }
}
