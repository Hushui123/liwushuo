package com.example.dllo.kaoshi.Four;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.dllo.kaoshi.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * Created by dllo on 16/9/18.
 */
public class Tongxinlu extends Fragment {

    private RecyclerView recyclerView;
    private ArrayList<MyTongxinBean> arrayList;
    private TongAdpter adpter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.tongxin, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = (RecyclerView) view.findViewById(R.id.rl);
        arrayList = new ArrayList<>();
        adpter = new TongAdpter(getContext());
        chaxun();
        adpter.setArrayList(arrayList);
        recyclerView.setAdapter(adpter);

        LinearLayoutManager manager=new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(manager);
    }

    public void chaxun() {
        ContentResolver provider = getContext().getContentResolver();

        if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Cursor cursor = provider.query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        while (cursor.moveToNext()){
            String date = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DATE));
            String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
            String name;
            if (cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)) != null) {
                name = cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                //    values.put("name", name);
            } else {
                name = "未知身份";
            }
            SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
            String time = format.format(Long.valueOf(date));
            MyTongxinBean bean = new MyTongxinBean();
            bean.setName(name);
            bean.setNum(number);
            bean.setTime(time);
            arrayList.add(bean);
        }
    }
}
