package com.example.dllo.kaoshi.main;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import com.example.dllo.kaoshi.Four.Tongxinlu;
import com.example.dllo.kaoshi.R;
import com.example.dllo.kaoshi.Seconed.Feixing;
import com.example.dllo.kaoshi.Three.Three;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ViewPager vp;
    private TabLayout tb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 引导页

        setContentView(R.layout.activity_main);

        vp = (ViewPager) findViewById(R.id.vp_main);
        tb = (TabLayout) findViewById(R.id.tb_main);

        ArrayList<Fragment> fragments =new ArrayList<>();
        fragments.add(new Feixing());
        fragments.add(new Three());
        fragments.add(new Tongxinlu());
        ArrayList<String> title=new ArrayList<>();
        title.add("第一个");
        title.add("第二个");
        title.add("第三个");
        MyAdpet adpet=new MyAdpet(getSupportFragmentManager());
        adpet.setFragments(fragments);
        adpet.setStrings(title);
        vp.setAdapter(adpet);
        tb.setupWithViewPager(vp);
    }
}
