package com.example.dllo.kaoshi.Three;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.dllo.kaoshi.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/18.
 */
public class ListAapter extends BaseAdapter{
    Context context;
    ArrayList<MyBean> arrayList;

    public ListAapter(Context context) {
        this.context = context;
    }

    public void setArrayList(ArrayList<MyBean> arrayList) {

        this.arrayList = arrayList;
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        return arrayList.size();

    }

    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHodle viewHodle=null;
        if (convertView == null) {
            convertView= LayoutInflater.from(context).inflate(R.layout.item,null);
            viewHodle =new ViewHodle(convertView);
            convertView.setTag(viewHodle);
        }else {
            viewHodle= (ViewHodle) convertView.getTag();
        }
        viewHodle.count.setText(arrayList.get(position).getCount());
        viewHodle.mima.setText(arrayList.get(position).getMima());
        return convertView;
    }

    class ViewHodle{

        private final TextView count;
        private final TextView mima;

        public ViewHodle(View convertView) {
            count = (TextView) convertView.findViewById(R.id.tv_count);
            mima = (TextView) convertView.findViewById(R.id.tv_mima);
        }
    }

}
