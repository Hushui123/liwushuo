package com.example.dllo.kaoshi.main;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/18.
 */
public class MyAdpet extends FragmentPagerAdapter {
    public void setFragments(ArrayList<Fragment> fragments) {
        this.fragments = fragments;
    }
    ArrayList<String> strings;

    public void setStrings(ArrayList<String> strings) {
        this.strings = strings;
    }

    ArrayList<Fragment> fragments;

    public MyAdpet(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return strings.get(position);
    }
}
