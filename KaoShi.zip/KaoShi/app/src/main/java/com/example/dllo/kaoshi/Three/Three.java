package com.example.dllo.kaoshi.Three;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.dllo.kaoshi.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/18.
 */
public class Three extends Fragment {

    private ListView lv;
    private MyGuangbo receiver;
    private ArrayList<MyBean> arrayList;
    private ListAapter apter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.three,null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        lv = (ListView) view.findViewById(R.id.lv);
        SQLiteDatabase database=getContext().openOrCreateDatabase("num.db",getContext().MODE_PRIVATE,null);
        arrayList = new ArrayList<>();
        Cursor cursor=database.query("xinxi",null,null,null,null,null,null);
        while (cursor.moveToNext()){
            String count=cursor.getString(cursor.getColumnIndex("count"));
            String maima=cursor.getString(cursor.getColumnIndex("mima"));

            MyBean bean =new MyBean();
            bean.setCount(count);
            bean.setMima(maima);
            arrayList.add(bean);
        }
        apter = new ListAapter(getContext());
        apter.setArrayList(arrayList);
        lv.setAdapter(apter);
        receiver = new MyGuangbo();
        IntentFilter filter =new IntentFilter();
        filter.addAction("faguanbo");
        getContext().registerReceiver(receiver,filter);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getContext().unregisterReceiver(receiver);
    }

    class MyGuangbo extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
             Bundle extras=intent.getExtras();
            MyBean bean =new MyBean();
            String count=extras.getString("count");
            String maima=extras.getString("mima");

            bean.setCount(count);
            bean.setMima(maima);
            arrayList.add(bean);
            apter.setArrayList(arrayList);
        }
    }
}
