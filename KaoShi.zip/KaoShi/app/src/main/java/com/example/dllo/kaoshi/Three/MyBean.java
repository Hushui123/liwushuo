package com.example.dllo.kaoshi.Three;

/**
 * Created by dllo on 16/9/18.
 */
public class MyBean {
    String count;
    String mima;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getMima() {
        return mima;
    }

    public void setMima(String mima) {
        this.mima = mima;
    }
}
