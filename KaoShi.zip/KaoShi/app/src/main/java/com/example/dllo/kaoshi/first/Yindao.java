package com.example.dllo.kaoshi.first;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.dllo.kaoshi.Ad.AdActivity;
import com.example.dllo.kaoshi.R;

import java.util.ArrayList;

public class Yindao extends AppCompatActivity {

    private ViewPager vp_first;
    private int[] arr = {R.mipmap.photo1, R.mipmap.photo2, R.mipmap.photo3, R.mipmap.photo4};
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_yindao);
        button = (Button) findViewById(R.id.btn_tiaoguo);
        vp_first = (ViewPager) findViewById(R.id.vp_first);


        SharedPreferences sp = getSharedPreferences("kaoshi", MODE_PRIVATE);
        SharedPreferences.Editor spEt = sp.edit();
        spEt.putBoolean("isfo", false);
        spEt.commit();

        ArrayList<ImageView> imageViews = new ArrayList<>();
        for (int i = 0; i < arr.length; i++) {
            ImageView iv = new ImageView(this);
            iv.setBackgroundResource(arr[i]);
            imageViews.add(iv);
        }

        MyApter apter = new MyApter();
        apter.setImageViews(imageViews);
        vp_first.setAdapter(apter);

        vp_first.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                if (position == 3) {
                    button.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentad = new Intent(Yindao.this, AdActivity.class);
                startActivity(intentad);
                finish();
            }
        });



    }
}
