package com.example.dllo.kaoshi.Ad;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.RelativeLayout;

import com.example.dllo.kaoshi.R;
import com.example.dllo.kaoshi.first.Yindao;
import com.example.dllo.kaoshi.main.MainActivity;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AdActivity extends AppCompatActivity {

    private RelativeLayout img_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences preferences = getSharedPreferences("kaoshi", MODE_PRIVATE);

        SharedPreferences.Editor first = preferences.edit();

        first.commit();

        Boolean isfo = preferences.getBoolean("isfo", true);
        if (isfo == true) {
            Intent intentYinDao = new Intent(this, Yindao.class);

            startActivity(intentYinDao);
            finish();
        }
        setContentView(R.layout.activity_ad);

        img_btn = (RelativeLayout) findViewById(R.id.img_ad);

        Img img =new Img();
        img.execute("http://img.zcool.cn/community/013475558a5298000000b18f51ce59.jpg");
       img_btn.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intentMain=new Intent(AdActivity.this,MainActivity.class);
               startActivity(intentMain);
               finish();
           }
       });
    }
    class Img extends AsyncTask<String,Void,Bitmap>{

        private Bitmap bitmap;

        @Override
        protected Bitmap doInBackground(String... params) {
            String str=params[0];

            try {
                URL url=new URL(str);

                HttpURLConnection connection= (HttpURLConnection) url.openConnection();
                if (HttpURLConnection.HTTP_OK == connection.getResponseCode()) {
                    InputStream in=connection.getInputStream();
                    bitmap = BitmapFactory.decodeStream(in);

                    in.close();
                    connection.disconnect();
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);

            BitmapDrawable bd=new BitmapDrawable(bitmap);
            img_btn.setBackground(bd);
        }
    }
}
