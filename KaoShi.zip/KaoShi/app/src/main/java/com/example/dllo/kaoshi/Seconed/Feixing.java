package com.example.dllo.kaoshi.Seconed;

import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.dllo.kaoshi.R;
import com.example.dllo.kaoshi.Shujuku.MySql;

/**
 * Created by dllo on 16/9/18.
 */
public class Feixing extends Fragment {

    private Button button;
    private TextView textView;
    private MyFei receiver = new MyFei();;
    private SQLiteDatabase database;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.feixing, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        textView = (TextView) view.findViewById(R.id.tv_fei);
        button = (Button) view.findViewById(R.id.btn_fei);


        IntentFilter filter=new IntentFilter();
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        getContext().registerReceiver(receiver, filter);
        MySql helper=new MySql(getContext(),"num.db",null,1);
        database = helper.getWritableDatabase();


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
                View view1 = LayoutInflater.from(getContext()).inflate(R.layout.denglu, null);

                final EditText zhanghao = (EditText) view1.findViewById(R.id.zhanghao);
                final EditText mima = (EditText) view1.findViewById(R.id.mima);

                builder.setTitle("登陆");
                builder.setNegativeButton("登陆", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ContentValues values =new ContentValues();
                        values.put("count",zhanghao.getText().toString());
                        values.put("mima",mima.getText().toString());
                        database.insert("xinxi",null,values);

                        Intent intent =new Intent("faguanbo");
                        intent.putExtra("count",zhanghao.getText().toString());
                        intent.putExtra("mima",mima.getText().toString());
                        getContext().sendBroadcast(intent,null);
                    }
                })
                        .setPositiveButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });

                builder.setView(view1);
                builder.show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getContext().unregisterReceiver(receiver);
    }

    class MyFei extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
            textView.setText("飞行模式改变了");
        }
    }
}
