package com.example.dllo.kaoshi.Four;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dllo.kaoshi.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/18.
 */
public class TongAdpter extends RecyclerView.Adapter<TongAdpter.ViewHodler> {
    public TongAdpter(Context context) {
        this.context = context;
    }

    Context context;
    ArrayList<MyTongxinBean> arrayList;

    public void setArrayList(ArrayList<MyTongxinBean> arrayList) {
        this.arrayList = arrayList;
    }

    @Override
    public TongAdpter.ViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.tongxinlu, parent, false);
        ViewHodler viewHodler = new ViewHodler(view);
        return viewHodler;
    }

    @Override
    public void onBindViewHolder(TongAdpter.ViewHodler holder, int position) {
        holder.tv_name.setText(arrayList.get(position).getName());
        holder.tv_num.setText(arrayList.get(position).getNum());
        holder.tv_time.setText(arrayList.get(position).getTime());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {

        private final TextView tv_name;
        private final TextView tv_num;
        private final TextView tv_time;

        public ViewHodler(View itemView) {
            super(itemView);
            tv_name = (TextView) itemView.findViewById(R.id.tv_tongxin);
            tv_num = (TextView) itemView.findViewById(R.id.tv_num);
            tv_time = (TextView) itemView.findViewById(R.id.tv_time);
        }
    }
}
