package com.example.dllo.kaoshi.Four;

/**
 * Created by dllo on 16/9/18.
 */
public class MyTongxinBean {
    String name;
    String num;
    String time;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
