package com.example.dllo.imagedemo;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.android.volley.toolbox.ImageLoader;

/**
 * Created by dllo on 16/9/22.
 * imageLoder 所需的L缓存
 */
public class MemoryCache implements ImageLoader.ImageCache {
    private LruCache<String, Bitmap> mLruCache;

    public MemoryCache() {
        long maxMemory = //获取程序运行时所使用的最大内存
                // 除以1024是为了将单位装欢成kb
                Runtime.getRuntime().maxMemory() / 1024;
        mLruCache = new LruCache<String, Bitmap>((int) (maxMemory / 10)) {
            // 用来确定每一个元素所占有的空间
            @Override

            protected int sizeOf(String key, Bitmap value) {
                // value.getByteCount() / 1024;
                // f返回值 是bi 所占有的空间 / 1024 是为了将单位转换成kb
                // 来与最大容器单位保持一致
                return value.getRowBytes() * value.getHeight() / 1024;
            }
        };
    }

    @Override
    public Bitmap getBitmap(String url) {

        return mLruCache.get(url);
    }

    @Override
    public void putBitmap(String url, Bitmap bitmap) {
        mLruCache.put(url,bitmap);
    }
}
