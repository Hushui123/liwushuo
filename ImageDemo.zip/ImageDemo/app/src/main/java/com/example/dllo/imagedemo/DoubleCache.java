package com.example.dllo.imagedemo;

import android.content.Context;
import android.graphics.Bitmap;

import com.android.volley.toolbox.ImageLoader;

/**
 * Created by dllo on 16/9/22.
 */
public class DoubleCache implements ImageLoader.ImageCache{
    private  MemoryCache memoryCache;
    private  DiskCache diskCache;

    public DoubleCache(Context context) {
        memoryCache = new MemoryCache();
        diskCache =new DiskCache(context);
    }

    @Override
    public Bitmap getBitmap(String url) {
        Bitmap bitmap;
        bitmap = memoryCache.getBitmap(url);
        if (bitmap == null) {
            // 内存缓存里并没用这张图片
            // 从硬盘里拿这张图片
            bitmap =diskCache.getBitmap(url);
        }
        return bitmap;
    }

    @Override
    public void putBitmap(String url, Bitmap bitmap) {
        memoryCache.putBitmap(url,bitmap);
        diskCache.putBitmap(url,bitmap);
    }
}
