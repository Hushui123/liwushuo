package com.example.dllo.imagedemo;

import android.animation.ObjectAnimator;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {
    private String url = "http://img.lanou3g.com//uploads/160324/1-160324155244W3.jpg";
    private Button get_img_btn;
    private ImageView imageView;
    private ImageLoader imageLoader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        get_img_btn = (Button) findViewById(R.id.get_img_btn);
        imageView = (ImageView) findViewById(R.id.main_iv);
        get_img_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getImage();
            }
        });

        RequestQueue queue = Volley.newRequestQueue(this);

        imageLoader = new ImageLoader(queue, new DoubleCache(this));


    }

    private void getImage() {
        //imageLoader.get(url, ImageLoader.getImageListener(imageView, R.mipmap.ic_launcher, R.mipmap.ic_launcher));
        imageLoader.get(url,new AnimImageListener(imageView));
    }

    // 自定义的imageListner
    // 来实现 图片请求成功后有一个渐变的动画效果
    class AnimImageListener implements ImageLoader.ImageListener {

        private ImageView mImageView;//请求成功后 直接设置这个imageView


        public AnimImageListener(ImageView mImageView) {
            this.mImageView = mImageView;
        }

        // 当图片请求成功后 会回调改方法
        // 当缸发起图片请求的时候 也会会调改方法 ()这个时候图片还没有请求下来
        @Override
        public void onResponse(ImageLoader.ImageContainer response, boolean isImmediate) {
            Bitmap bitmap = response.getBitmap();
            if (bitmap == null) {
                // 这次回调是缸发起请求呀的时候
                // 就把默认图片 设置给ImageView
                mImageView.setImageResource(R.mipmap.ic_launcher);
            } else {
                // 图片请求成功
                mImageView.setImageBitmap(bitmap);
//                AlphaAnimation alphaAnimation = new AlphaAnimation(0, 1);
//                alphaAnimation.setDuration(2000);
//                mImageView.setAnimation(alphaAnimation);
//                alphaAnimation.start();

                ObjectAnimator objectAnimator =ObjectAnimator.ofFloat(mImageView,"alpha",0,1);
                objectAnimator.setDuration(2000);
                ObjectAnimator animator = ObjectAnimator.ofFloat(mImageView,"translationX",2,3,6,8);
                animator.setDuration(2000);
                animator.start();
                objectAnimator.start();
            }
        }

        // 图片请求失败;
        @Override
        public void onErrorResponse(VolleyError error) {
            mImageView.setImageResource(R.mipmap.ic_launcher);
        }
    }
}
