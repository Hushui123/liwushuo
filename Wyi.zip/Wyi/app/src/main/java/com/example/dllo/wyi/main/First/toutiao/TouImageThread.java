package com.example.dllo.wyi.main.First.toutiao;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by dllo on 16/9/3.
 */
public class TouImageThread extends Thread {
    private Handler handler;
    private String image;

    public TouImageThread() {
    }

    public TouImageThread(Handler handler, String image) {
        this.handler = handler;
        this.image = image;
    }
    public Bitmap imageParse(String ima){
        Bitmap bitmap=null;
        try {
            URL url =new URL(ima);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            if (HttpURLConnection.HTTP_OK == connection.getResponseCode()) {
                InputStream inputStream = connection.getInputStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                connection.disconnect();
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    @Override
    public void run() {
        super.run();

        Bitmap bit=imageParse(image);
        Message msg =new Message();
        msg.what=101;
        msg.obj=bit;
        handler.sendMessage(msg);
    }
}
