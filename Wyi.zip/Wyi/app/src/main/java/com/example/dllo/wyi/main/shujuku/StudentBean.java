package com.example.dllo.wyi.main.shujuku;

/**
 * Created by ggs on 16/8/25.
 */
public class StudentBean {
    String name;
    String age;

    public StudentBean(String name, String age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }
}
