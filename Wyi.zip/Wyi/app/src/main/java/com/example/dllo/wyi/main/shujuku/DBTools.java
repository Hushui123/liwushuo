package com.example.dllo.wyi.main.shujuku;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

/**
 * Created by ggs on 16/8/25.
 */
public class DBTools {
    private SQLiteDatabase database;
    private Cursor cursor;

    public DBTools(Context context) {
        MyHelper helper = new MyHelper(context, DBValues.SQL_NAME , null , 1);
        database = helper.getWritableDatabase();
    }

    public void  insertDB(StudentBean bean){
            ContentValues values = new ContentValues();
            values.put(DBValues.TABLE_STUDENT_NAME , bean.getName());
            values.put(DBValues.TABLE_STUDENT_AGE , bean.getAge());
            database.insert(DBValues.TABLE_NAME , null , values);

    }

    public void deleteAllDB(){

        database.delete(DBValues.TABLE_NAME , null , null);
    }

    public void deleteSelectedDB(String whereClause , String[] whereArgs){

        database.delete(DBValues.TABLE_NAME , whereClause + " = ?" , whereArgs);

    }

    /**
     *
     * @param bean : 修改后的数据
     * @param whereClause :修改的条件
     * @param whereArgs : 对应的修改的列名
     */
    public void updateDB(StudentBean bean ,String whereClause , String[] whereArgs){
        ContentValues values = new ContentValues();
        values.put(DBValues.TABLE_STUDENT_NAME , bean.getName());
        values.put(DBValues.TABLE_STUDENT_AGE, bean.getAge());
        database.update(
                DBValues.TABLE_NAME,
                values ,
                whereClause + " = ?",
                whereArgs);
    }

    public ArrayList<StudentBean> queryAllDB(){
        ArrayList<StudentBean> studentBeens = new ArrayList<>();
        cursor = database.query(DBValues.TABLE_NAME,
                null, null, null, null, null, null);
        if (cursor != null){
            while (cursor.moveToNext()){
                String name = cursor.
                        getString(cursor.getColumnIndex(DBValues.TABLE_STUDENT_NAME));
                String age = cursor.
                        getString(cursor.getColumnIndex(DBValues.TABLE_STUDENT_AGE));
                StudentBean bean = new StudentBean(name , age);
                studentBeens.add(bean);
            }
        }
        return studentBeens;
    }


}
