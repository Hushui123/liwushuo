package com.example.dllo.wyi.main.First;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/20.
 */
public class newsAapter extends FragmentPagerAdapter {
    ArrayList<Fragment> fragments;
    ArrayList<String> title = new ArrayList<>();

    public newsAapter(FragmentManager fm, ArrayList<Fragment> fragments) {
        super(fm);
        this.fragments = fragments;
        this.title.add("头条");
        this.title.add("精选");
        this.title.add("娱乐");
        this.title.add("体育");
        this.title.add("网易号");
        this.title.add("科技");
        this.title.add("事实");
        this.title.add("图片");
    }

    public newsAapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments == null ? 0 : fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return title.get(position);
    }
}
