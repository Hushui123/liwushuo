package com.example.dllo.wyi.main.First.yuyue;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dllo.wyi.R;
import com.example.dllo.wyi.main.First.toutiao.MyApter;
import com.example.dllo.wyi.main.First.toutiao.TouMybean;
import com.example.dllo.wyi.main.First.toutiao.Wv;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Created by dllo on 16/8/20.
 */
public class Yuyue extends android.support.v4.app.Fragment {

    private Context context;
    private PullToRefreshListView pullToRefreshListView;
    private Handler handler;
    private ArrayList<TouMybean> list;
    private ListView listView;


    int []arr ={R.mipmap.photo1,R.mipmap.photo2};
    String[] arr1 = new String[2];
    private ViewPager vp;
    private TextView title;
    private int cuitem;
    private ScheduledExecutorService scheduledExecutorService;
    private ArrayList<ImageView> imgViews =new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.yuyue, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        pullToRefreshListView = (PullToRefreshListView) view.findViewById(R.id.Refresh_lv);

        View view1 = LayoutInflater.from(context).inflate(R.layout.lunbo, null);

        listView = pullToRefreshListView.getRefreshableView();
        listView.addHeaderView(view1);
        vp = (ViewPager) view1.findViewById(R.id.vp);

        handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                if (msg.what == 201) {
                    list = (ArrayList<TouMybean>) msg.obj;

                    TouAdpter_Yuyue adpter = new TouAdpter_Yuyue(context);
                    adpter.setMybeanArrayList(list);
                    pullToRefreshListView.setAdapter(adpter);

                    TuPian tuPian = new TuPian();
                    tuPian.execute(list.get(0).getAds().get(0).getImgsrc(), list.get(0).getImgsrc());
                    Log.d("Yuyue1", list.get(0).getAds().get(0).getImgsrc());
                    Log.d("Yuyue1", list.get(0).getImgsrc());

                }
                return false;
            }
        });
        new TouThread_Yuyue(handler, "0-20").start();
        pollu();
        initData();

//        ArrayList<ImageView> imgViews =new ArrayList<>();
//        for (int i = 0; i < arr1.length; i++) {
//            ImageView iv=new ImageView(context);
//            iv.setBackgroundResource(arr[i]);
//            imgViews.add(iv);
//        }
//
//        MyApter apter=new MyApter();
//        apter.setImageViews(imgViews);
//        vp.setAdapter(apter);

//        arr1[0] = "hahah";
//        title.setText(arr1[0]);
//
//        vp.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//            private int cuitem;
//
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//                title.setText(arr1[position]);
//
//                cuitem = position;
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//            }
//
//
//        });

        pullToRefreshListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TouMybean touMybean = (TouMybean) parent.getItemAtPosition(position);
                if (touMybean.getUrl_3w() != null && !"".equals(touMybean.getUrl_3w())) {
                    Intent it = new Intent(context, Wv.class);
                    String uri = touMybean.getUrl_3w();
                    it.putExtra("webview", uri);
                    startActivity(it);
                } else {
                    Toast.makeText(context, "内容不存在", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    public void pollu() {
        pullToRefreshListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener2<ListView>() {

            @Override
            public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
                new AsyncTask<Void, Void, Void>() {

                    @Override
                    protected Void doInBackground(Void... params) {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void aVoid) {
                        super.onPostExecute(aVoid);

                        new TouThread_Yuyue(handler, "0-20").start();
                        pullToRefreshListView.onRefreshComplete();//通知完成
                    }
                }.execute();

            }

            @Override
            public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
                new AsyncTask<Void, Void, Void>() {
                    @Override
                    protected Void doInBackground(Void... params) {
                        try {
                            Thread.sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        return null;
                    }

                    @Override
                    protected void onPostExecute(Void aVoid) {
                        super.onPostExecute(aVoid);
                        new TouThread_Yuyue(handler, "20-40").start();
                        pullToRefreshListView.onRefreshComplete();//通知完成
                    }
                }.execute();
            }
        });

    }

    private void initData() {
        // 设置PullToRefreshListView的模式
        // pullToRefreshListView.setMode(PullToRefreshBase.Mode.BOTH);

        // 设置PullRefreshListView上提加载时的加载提示
        pullToRefreshListView.setMode(PullToRefreshBase.Mode.BOTH);
        pullToRefreshListView.getLoadingLayoutProxy(false, true).setPullLabel("上拉加载...");
        pullToRefreshListView.getLoadingLayoutProxy(false, true).setRefreshingLabel("正在加载...");
        pullToRefreshListView.getLoadingLayoutProxy(false, true).setReleaseLabel("松开加载更多...");

        // 设置PullRefreshListView下拉加载时的加载提示
        pullToRefreshListView.getLoadingLayoutProxy(true, false).setPullLabel("下拉刷新...");
        pullToRefreshListView.getLoadingLayoutProxy(true, false).setRefreshingLabel("正在加载...");
        pullToRefreshListView.getLoadingLayoutProxy(true, false).setReleaseLabel("松开加载更多...");

    }

//    @Override
//    public void onStart() {
//        super.onStart();
//        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
//        scheduledExecutorService.scheduleAtFixedRate(new ViewPagerTask(), 2, 2, TimeUnit.SECONDS);
//    }
//
//    private class ViewPagerTask implements Runnable {
//        @Override
//        public void run() {
//            cuitem = (cuitem + 1) % arr1.length;
//            mHandler.sendEmptyMessage(0);
//        }
//    }
//
//    private Handler mHandler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            //  super.handleMessage(msg);
//            vp.setCurrentItem(cuitem);
//
//
//        }
//    };
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        if (scheduledExecutorService != null) {
//            scheduledExecutorService.shutdown();
//            scheduledExecutorService = null;
//        }
//    }

    class TuPian extends AsyncTask<String, Void, ArrayList<Bitmap>> {

        @Override
        protected ArrayList<Bitmap> doInBackground(String... params) {
            ArrayList<Bitmap> bitmap = new ArrayList<>();
            HttpURLConnection connection = null;
            try {

                for (int i = 0; i < 2; i++) {
                    URL url = new URL(params[i]);
                    connection = (HttpURLConnection) url.openConnection();
                    if (HttpURLConnection.HTTP_OK == connection.getResponseCode()) {
                        InputStream inputStream = connection.getInputStream();
                        Bitmap bit1 = BitmapFactory.decodeStream(inputStream);

                        bitmap.add(bit1);


                        inputStream.close();
                        connection.disconnect();
                    }

                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(ArrayList<Bitmap> bitmap) {
            super.onPostExecute(bitmap);
            for (int i = 0; i < arr.length; i++) {
                ImageView iv = new ImageView(getContext());
                iv.setImageBitmap(bitmap.get(i));
                //iv.setBackgroundResource();
                imgViews.add(iv);
                MyApter apter = new MyApter();
                apter.setImageViews(imgViews);
                Log.d("Doutiao", "kakak");
                vp.setAdapter(apter);
            }
        }
    }
}
