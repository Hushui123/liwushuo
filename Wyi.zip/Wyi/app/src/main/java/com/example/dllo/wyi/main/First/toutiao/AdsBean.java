package com.example.dllo.wyi.main.First.toutiao;

/**
 * Created by dllo on 16/9/10.
 */
public class AdsBean {

    private String title;
    private String imgsrc;

    public AdsBean() {
    }

    public AdsBean(String title, String imgsrc) {
        this.title = title;
        this.imgsrc = imgsrc;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImgsrc() {
        return imgsrc;
    }

    public void setImgsrc(String imgsrc) {
        this.imgsrc = imgsrc;
    }
}
