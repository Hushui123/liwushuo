package com.example.dllo.wyi.main.main;

import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.example.dllo.wyi.R;
import com.example.dllo.wyi.main.First.news;
import com.example.dllo.wyi.main.Second.DirectSeeding;
import com.example.dllo.wyi.main.five.Me;
import com.example.dllo.wyi.main.four.Topic;
import com.example.dllo.wyi.main.three.Olympic;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {



    private TextView tp,oly,news,me,seed;
    private FrameLayout frameLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tp = (TextView) findViewById(R.id.tp_text);
        oly = (TextView) findViewById(R.id.oly_text);
        news = (TextView) findViewById(R.id.news_text);
        me = (TextView) findViewById(R.id.me_text);
        seed = (TextView) findViewById(R.id.seed_text);

        frameLayout = (FrameLayout) findViewById(R.id.fl_layout);

        tp.setOnClickListener(this);
        oly.setOnClickListener(this);
        news.setOnClickListener(this);
        me.setOnClickListener(this);
        seed.setOnClickListener(this);

        FragmentManager manager =getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.replace(R.id.fl_layout,new news());
        transaction.commit();

    }

    @Override
    public void onClick(View v) {
        FragmentManager manager=getSupportFragmentManager();
        FragmentTransaction transaction=manager.beginTransaction();

        switch (v.getId()){
            case R.id.news_text:
                    transaction.replace(R.id.fl_layout,new news());
                break;
            case R.id.seed_text:
                transaction.replace(R.id.fl_layout,new DirectSeeding());
                break;
            case R.id.oly_text:
                transaction.replace(R.id.fl_layout,new Olympic());
                break;
            case R.id.tp_text:
                transaction.replace(R.id.fl_layout,new Topic());
                break;
            case R.id.me_text:
                transaction.replace(R.id.fl_layout,new Me());
                break;
            default:
                break;
        }
        transaction.commit();
    }
}
