package com.example.dllo.wyi.main.First.toutiao;

import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/7.
 */
public class MyApter extends PagerAdapter {
    ArrayList<ImageView> imageViews;

    @Override
    public int getCount() {
        return imageViews == null ? 0 : imageViews.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }
//  在滑动的时候要移除item
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        //super.destroyItem(container, position, object);
        container.removeView(imageViews.get(position));

    }

    public void setImageViews(ArrayList<ImageView> imageViews) {
        this.imageViews = imageViews;
        notifyDataSetChanged();
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        container.addView(imageViews.get(position));
        return imageViews.get(position);
    }
}
