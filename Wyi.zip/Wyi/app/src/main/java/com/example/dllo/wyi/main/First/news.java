package com.example.dllo.wyi.main.First;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.dllo.wyi.R;
import com.example.dllo.wyi.main.First.Tiyu.Tiyu;
import com.example.dllo.wyi.main.First.toutiao.Doutiao;
import com.example.dllo.wyi.main.First.yuyue.Yuyue;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/20.
 */
public class news extends Fragment{

    private TabLayout tabLayout;
    private ViewPager viewPager;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.news,null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tabLayout = (TabLayout)view.findViewById(R.id.tl_tabLayout);
        viewPager = (ViewPager)view.findViewById(R.id.vp_viewPager);




        ArrayList<Fragment> fragments=new ArrayList<>();

        fragments.add(new Doutiao());
        fragments.add(new Jingxuan());
        fragments.add(new Yuyue());
        fragments.add(new Tiyu());
        fragments.add(new WantyiHao());
        fragments.add(new Keji());
        fragments.add(new Shishi());
        fragments.add(new Tupian());

        newsAapter myAdpter =new newsAapter(getChildFragmentManager(),fragments);
        viewPager.setAdapter(myAdpter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);
    }


    //    @Override
//    protected void onStop() {
//        super.onStop();
//        if ( scheduledExecutorService != null) {
//            scheduledExecutorService.shutdown();
//            scheduledExecutorService=null;
//        }
//    }

}
