package com.example.dllo.wyi.main.First.yuyue;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.example.dllo.wyi.main.First.toutiao.AdsBean;
import com.example.dllo.wyi.main.First.toutiao.TouMybean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by dllo on 16/9/3.
 */
public class TouThread_Yuyue extends Thread {
    private Handler handler;
    private String str1;

    public TouThread_Yuyue() {
    }

    public TouThread_Yuyue(Handler handler, String str1) {
        this.handler = handler;
        this.str1 = str1;
        Log.d("TouThread_Yuyue", str1);
    }

    @Override
    public void run() {
        super.run();
        String str = readFile("http://c.3g.163.com/nc/article/list/T1348648517839/"+str1+".html");
        ArrayList<TouMybean> datas = jsonParse(str);
        Message msg = new Message();
        msg.what = 201;
        msg.obj = datas;
        handler.sendMessage(msg);
    }

    private ArrayList<TouMybean> jsonParse(String str) {
        ArrayList<TouMybean> list = new ArrayList<>();
        try {
            JSONObject jsonData = new JSONObject(str);
            JSONArray jsonArr = jsonData.getJSONArray("T1348648517839");
            for (int i = 0; i < jsonArr.length(); i++) {

                JSONObject obj = jsonArr.getJSONObject(i);
                TouMybean bean = new TouMybean();
                if (i == 0) {
                    if (obj.has("ads")) {

                        List<AdsBean> adsBeanList = new ArrayList<>();
                        JSONArray jsonArray = obj.getJSONArray("ads");
                        for (int j = 0; j < jsonArray.length(); j++) {
                            JSONObject jo = jsonArray.getJSONObject(j);
                            String title = (String) jo.get("title");
                            String imgSrc = jo.getString("imgsrc");
                            AdsBean ads = new AdsBean(title, imgSrc);
                            adsBeanList.add(ads);
                        }
                        bean.setAds(adsBeanList);
                    }
                }
                if (obj.has("title")) {
                    String title = obj.getString("title");
                    bean.setTilte(title);
                }
                if (obj.has("source")) {
                    bean.setSource(obj.getString("source"));

                }
                if (obj.has("imgsrc")) {
                    bean.setImgsrc(obj.getString("imgsrc"));

                }
                if (obj.has("url_3w")) {
                    String url_3w = obj.getString("url_3w");
                    bean.setUrl_3w(url_3w);
                }


                list.add(bean);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return list;
    }

    private String readFile(String pathname) {
        String result = new String();

        try {
            URL uri = new URL(pathname);
            HttpURLConnection connection = (HttpURLConnection) uri.openConnection();
            if (HttpURLConnection.HTTP_OK == connection.getResponseCode()) {
                InputStream inputStream = connection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader buff = new BufferedReader(inputStreamReader);
                String line = "";
                while ((line = buff.readLine()) != null) {
                    result += line;
                }
                buff.close();
                inputStreamReader.close();
                inputStream.close();
                connection.disconnect();
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }
}
