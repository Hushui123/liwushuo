package com.example.dllo.wyi.main.First.toutiao;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.example.dllo.wyi.R;

public class Wv extends AppCompatActivity {

    private WebView wv;
    private String url1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        Intent intent=getIntent();
        url1 = intent.getStringExtra("webview");
        initView();
    }

    public void initView(){
        wv = (WebView) findViewById(R.id.wv);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.loadUrl(url1);
        wv.getSettings().setUseWideViewPort(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.setWebViewClient(new WebViewClient(){
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                Log.d("访问网址：",url) ;
                wv.loadUrl(url);
                return super.shouldOverrideUrlLoading(view, url);
            }
        });
    }
    /**
     * 这个方法不好用
     */
//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        if((keyCode==KeyEvent.KEYCODE_BACK)&&wv.canGoBack()) {
//            //如果可以回退
//            wv.goBack() ;
//            return true ;
//        }
//        return super.onKeyDown(keyCode, event);
//    }

}
