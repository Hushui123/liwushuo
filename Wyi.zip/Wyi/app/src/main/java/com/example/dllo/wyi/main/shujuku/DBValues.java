package com.example.dllo.wyi.main.shujuku;

/**
 * Created by ggs on 16/8/25.
 */
public class DBValues {

    //数据库的名
    public static String SQL_NAME = "Person.db";

    //表名
    public static String TABLE_NAME = "student";
    //student 的name列
    public  static  String TABLE_STUDENT_NAME = "name";
    //student 的 age 列
    public static String TABLE_STUDENT_AGE = "age";


}
