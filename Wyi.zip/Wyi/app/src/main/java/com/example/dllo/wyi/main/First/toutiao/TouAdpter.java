package com.example.dllo.wyi.main.First.toutiao;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.dllo.wyi.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/3.
 */
public class TouAdpter  extends BaseAdapter{

    Context context;
    private Handler handler;
    ArrayList<TouMybean> mybeanArrayList;

    public void setMybeanArrayList(ArrayList<TouMybean> mybeanArrayList) {
        this.mybeanArrayList = mybeanArrayList;
        notifyDataSetChanged();
    }

    public TouAdpter(Context context) {

        this.context = context;
    }

    @Override
    public int getCount() {
        return mybeanArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return mybeanArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        TouViewHodler viewHodler =null;
        if(convertView == null){
            convertView= LayoutInflater.from(context).inflate(R.layout.doutiao_item,null);
            viewHodler =new TouViewHodler(convertView);
            convertView.setTag(viewHodler);
        }else {
            viewHodler= (TouViewHodler) convertView.getTag();
        }
        viewHodler.title.setText(mybeanArrayList.get(position).getTilte());
        viewHodler.sorce.setText(mybeanArrayList.get(position).getSource());
        final String str =mybeanArrayList.get(position).getImgsrc();
        final ImageView img = (ImageView) convertView.findViewById(R.id.img_toutiao);
        Picasso.with(context).load(str).into(img);
//
//        handler =new Handler(new Handler.Callback() {
//            @Override
//            public boolean handleMessage(Message msg) {
//                if (msg.what == 101) {
//                    Bitmap bit= (Bitmap) msg.obj;
//
//
//                   // img.setImageBitmap(bit);
//               }
//                return false;
//            }
//        });
//        new TouImageThread(handler,str).start();

        return convertView;
    }

    class TouViewHodler{

        private final TextView title;
        private final TextView sorce;

        public TouViewHodler(View convertView) {
            title = (TextView) convertView.findViewById(R.id.tv_doutiao_item);
            sorce = (TextView) convertView.findViewById(R.id.tv_doutiao_laiyuan_item);
        }
    }
}
