package com.example.dllo.wyi.main.First.toutiao;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.dllo.wyi.R;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by dllo on 16/8/20.
 */
public class Doutiao extends android.support.v4.app.Fragment {

    private Context context;
    private ListView listView_toutiao;
    private Handler handler;


    String[] arr = new String[4];
    String[] arr1 = new String[4];
    private ViewPager vp;
    private TextView title;
    private int cuitem;
    private ScheduledExecutorService scheduledExecutorService;
    private ArrayList<ImageView> imgViews;
    private ArrayList<TouMybean> dt;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.doutiao, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        listView_toutiao = (ListView) view.findViewById(R.id.lv_toutiao);


        View view1 = LayoutInflater.from(context).inflate(R.layout.lunbo, null);
        listView_toutiao.addHeaderView(view1);
        vp = (ViewPager) view1.findViewById(R.id.vp);
        title = (TextView) view1.findViewById(R.id.tv);
        imgViews = new ArrayList<>();

        handler = new Handler(new Handler.Callback() {

            @Override
            public boolean handleMessage(Message msg) {

                if (100 == msg.what) {

                    dt = (ArrayList<TouMybean>) msg.obj;
                    for (int i = 0; i < arr1.length; i++) {
                        arr1[i] = dt.get(0).getAds().get(i).getTitle();
                        Log.d("Doutiao22", dt.get(0).getAds().get(i).getImgsrc());

                    }
                    TuPian tuPian = new TuPian();
                    tuPian.execute(dt.get(0).getAds().get(0).getImgsrc(),
                            dt.get(0).getAds().get(1).getImgsrc(),
                            dt.get(0).getAds().get(2).getImgsrc(),
                            dt.get(0).getAds().get(3).getImgsrc());

                    TouAdpter adpter = new TouAdpter(context);
                    adpter.setMybeanArrayList(dt);
                    listView_toutiao.setAdapter(adpter);


                    listView_toutiao.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            TouMybean touMybean = (TouMybean) parent.getItemAtPosition(position);
                            if (touMybean.getUrl_3w() != null && !"".equals(touMybean.getUrl_3w())) {
                                //    Log.d("Doutiao", dt.get(position).getUrl_3w());
//                                Uri uri = Uri.parse(touMybean.getUrl_3w());
//                                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                                Intent it =new Intent(context,Wv.class);
                                String uri=touMybean.getUrl_3w();
                                Log.d("Doutiao", "uri:" + uri);
                                it.putExtra("webview",uri);

                                startActivity(it);


                            } else {
                                Toast.makeText(context, "内容不存在", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });


                }
                return false;
            }
        });

        new TouThread(handler).start();


        title.setText(arr1[0]);

        vp.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            private int cuitem;

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                title.setText(arr1[position]);

                cuitem = position;
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }


        });
    }

    @Override
    public void onStart() {
        super.onStart();
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        scheduledExecutorService.scheduleAtFixedRate(new ViewPagerTask(), 2, 2, TimeUnit.SECONDS);
    }

    private class ViewPagerTask implements Runnable {
        @Override
        public void run() {
            cuitem = (cuitem + 1) % arr1.length;
            mHandler.sendEmptyMessage(0);
        }
    }

    private Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            //  super.handleMessage(msg);
            vp.setCurrentItem(cuitem);


        }
    };

    @Override
    public void onStop() {
        super.onStop();
        if (scheduledExecutorService != null) {
            scheduledExecutorService.shutdown();
            scheduledExecutorService = null;
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    class TuPian extends AsyncTask<String, Void, ArrayList<Bitmap>> {

        @Override
        protected ArrayList<Bitmap> doInBackground(String... params) {
            ArrayList<Bitmap> bitmap = new ArrayList<>();
            HttpURLConnection connection = null;
            try {

                for (int i = 0; i < 4; i++) {
                    URL url = new URL(params[i]);
                    connection = (HttpURLConnection) url.openConnection();
                    if (HttpURLConnection.HTTP_OK == connection.getResponseCode()) {
                        InputStream inputStream = connection.getInputStream();
                        Bitmap bit1 = BitmapFactory.decodeStream(inputStream);

                        bitmap.add(bit1);


                        inputStream.close();
                        connection.disconnect();
                    }

                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return bitmap;
        }

        @Override
        protected void onPostExecute(ArrayList<Bitmap> bitmap) {
            super.onPostExecute(bitmap);
            for (int i = 0; i < arr.length; i++) {
                ImageView iv = new ImageView(context);
                iv.setImageBitmap(bitmap.get(i));
                //iv.setBackgroundResource();
                imgViews.add(iv);
                MyApter apter = new MyApter();
                apter.setImageViews(imgViews);
                Log.d("Doutiao", "kakak");
                vp.setAdapter(apter);
            }
        }
    }
}

