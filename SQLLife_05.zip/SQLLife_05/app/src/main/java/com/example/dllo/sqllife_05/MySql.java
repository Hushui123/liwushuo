package com.example.dllo.sqllife_05;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by dllo on 16/8/24.
 */
public class MySql extends SQLiteOpenHelper {
    public MySql(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }
        // z在这个方法里进行数据的操作
    //这个方法只有在第一次初始化helper中调用
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d("MySql", "onCreate");
        db.execSQL("create table people(id integer primary key autoincrement,name text,age integer)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
