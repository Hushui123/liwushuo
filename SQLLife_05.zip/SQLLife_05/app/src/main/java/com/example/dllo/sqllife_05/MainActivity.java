package com.example.dllo.sqllife_05;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button dele, add, query, update, creat;
    private SQLiteDatabase database;
    private ArrayList<Student> studentArrayLis;
    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.delelt_btn).setOnClickListener(this);
        findViewById(R.id.add_btn).setOnClickListener(this);
        findViewById(R.id.query_btn).setOnClickListener(this);
        findViewById(R.id.update_btn).setOnClickListener(this);
        findViewById(R.id.create_btn).setOnClickListener(this);

        tv = (TextView) findViewById(R.id.text_show);
        // 1 数据库的名字  2参数代表访问这个数据库的权限 3反正用不上

        // 第一种SQl语句实现操作,增删改差
        // 使用SQLiteOpenHelper类创建管理数据库
        // database = this.openOrCreateDatabase("lanou.db", MODE_PRIVATE, null);
        studentArrayLis = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Student student = new Student("may" + i, 20 + i);
            studentArrayLis.add(student);
        }


        MySql mySql = new MySql(this, "lantan.db", null, 1);
        //mySql.getReadableDatabase();
        //执行这个方法后系统会调用helper类中的create方法
        database = mySql.getWritableDatabase();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.create_btn:
                // id 是列表的编号primary key主键
                //database              eate table student(id integer primary key autoincrement,name text,age integer)");
                break;
            case R.id.add_btn:
                // 添加SQl语句
//                for (int i = 0; i <20 ; i++) {
//                    database.execSQL("insert into student (name,age) values(?,?)", new String[]{studentArrayLis.get(i).getName(), studentArrayLis.get(i).getAge()+""});
//                }
                //使用heiper类实现添加

                ContentValues values = new ContentValues();
                values.put("name", "aaaa");
                values.put("age", 16);
                database.insert("people", "name", values);

                break;
            case R.id.delelt_btn:
                // database.execSQL("delete from student where name=?", new String[]{"may0"});
                database.delete("people","name=?",new String[]{"aaaa"});
                break;
            case R.id.update_btn:
                ContentValues values1=new ContentValues();
                values1.put("name","苍老师");
                values1.put("age",20);
                /**
                 * 2想修改后的数据
                 * 3想要修改那一列的数据
                 * 4修改前的数据
                 */
                database.update("people",values1,"name=?",new String[]{"aaaa"});
                //第一个问号是修改后的值第二个问号是修改前的值
                //database.execSQL("update student set name =? where name=?",new String[]{"账号","daada"});
                break;
            case R.id.query_btn:
                // 查询SQL *查找student所有的数据
                // Cursor游标
//                Cursor cursor = database.rawQuery("select * from people", null);
//                if (cursor != null) {
//                    while (cursor.moveToNext()) {
//                        String name = cursor.getString(cursor.getColumnIndex("name"));
//                        int age = cursor.getInt(cursor.getColumnIndex("age"));
//                        Log.d("MainActivity", name + age);
//
//                        tv.setText(name + "" + age);
//                    }
//                    cursor.close();
//                }
                /**
                 *   boolean distinct,去重复
                 *   tring table,表名
                 *   String[] columns,查询的列名如果是null是查询所有的
                 *   String selection,查询的条件"name ="
                 *   String[] selectionArgs 查询条件的值 new String[]{"张三"}
                 *   String groupBy,
                 *   String having
                 *   String orderBy
                 *   String limit,
                 *   CancellationSignal cancellationSignal
                 */
                Cursor cursor =  database.query("people",null,null,null,null,null,null);
                if(cursor!=null){
                    while (cursor.moveToNext()) {
                        String name = cursor.getString(cursor.getColumnIndex("name"));
                        int age = cursor.getInt(cursor.getColumnIndex("age"));
                        Log.d("MainActivity", name + age);

                        tv.setText(name + "" + age);
                    }
                    cursor.close();
                }
                break;

        }
    }
}
