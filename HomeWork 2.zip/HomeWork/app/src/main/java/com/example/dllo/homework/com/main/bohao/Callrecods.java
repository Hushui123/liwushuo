package com.example.dllo.homework.com.main.bohao;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.dllo.homework.R;

/**
 * Created by dllo on 16/8/18.
 */
public class Callrecods extends Fragment implements View.OnClickListener {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.callrecords,null);
    }
    private TextView Te_call;
    private ImageView ic_key0,ic_key1,ic_key2,ic_key3,ic_key4,ic_key5,ic_key6,ic_key7,ic_key8,ic_key9;
    private ImageView ic_call,ic_pound,ic_hash;
    private Button del;
    private Context context;
    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Te_call=(TextView)view.findViewById(R.id.Te_ecall);
        ic_key0=(ImageView)view.findViewById(R.id.ic_key0);
        ic_key1=(ImageView)view.findViewById(R.id.ic_key1);
        ic_key2=(ImageView)view.findViewById(R.id.ic_key2);
        ic_key3=(ImageView)view.findViewById(R.id.ic_key3);
        ic_key4=(ImageView)view.findViewById(R.id.ic_key4);
        ic_key5=(ImageView)view.findViewById(R.id.ic_key5);
        ic_key6=(ImageView)view.findViewById(R.id.ic_key6);
        ic_key7=(ImageView)view.findViewById(R.id.ic_key7);
        ic_key8=(ImageView)view.findViewById(R.id.ic_key8);
        ic_key9=(ImageView)view.findViewById(R.id.ic_key9);
        ic_call=(ImageView)view.findViewById(R.id.ic_call);
        ic_pound=(ImageView)view.findViewById(R.id.ic_pound);
        ic_hash=(ImageView)view.findViewById(R.id.ic_hash);
        del=(Button)view.findViewById(R.id.del);



        ic_key0.setOnClickListener(this);
        ic_key1.setOnClickListener(this);
        ic_key2.setOnClickListener(this);
        ic_key3.setOnClickListener(this);
        ic_key4.setOnClickListener(this);
        ic_key5.setOnClickListener(this);
        ic_key6.setOnClickListener(this);
        ic_key7.setOnClickListener(this);
        ic_key8.setOnClickListener(this);
        ic_key9.setOnClickListener(this);
        ic_call.setOnClickListener(this);
        ic_pound.setOnClickListener(this);
        ic_hash.setOnClickListener(this);
        del.setOnClickListener(this);


    }
    String Str="";

    @Override
    public void onClick(View v) {

        switch (v.getId()){
            case R.id.ic_key0:
                Str+="0";
                break;
            case R.id.ic_key1:
                Str+="1";
                break;
            case R.id.ic_key2:
                Str+="2";
                break;
            case R.id.ic_key3:
                Str+="3";
                break;
            case R.id.ic_key4:
                Str+="4";
                break;
            case R.id.ic_key5:
                Str+="5";
                break;
            case R.id.ic_key6:
                Str+="6";
                break;
            case R.id.ic_key7:
                Str+="7";
                break;
            case R.id.ic_key8:
                Str+="8";
                break;
            case R.id.ic_key9:
                Str+="9";
                break;
            case R.id.ic_call:
                Intent hiddenI = new Intent(Intent.ACTION_CALL);
                // 设置data数据
                // 访问拨号界面

                Uri dataU = Uri.parse("tel:" + Str);
                hiddenI.setData(dataU);
                startActivity(hiddenI);
                // 获取系统时间
//                SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日    HH:mm:ss     ");
//                Date curDate = new Date(System.currentTimeMillis());//获取当前时间
//                String str = formatter.format(curDate);
//                //打开数据库
//                SQLiteDatabase database3 =context.openOrCreateDatabase("mybean.db", Context.MODE_PRIVATE, null);
//
//                ContentValues values = new ContentValues();
//                values.put("time", str);
//                values.put("name","lalal");
//                values.put("num", Te_call.getText()+"");
//                //第一个参数:表名
//                //第二个参数: 代表某一列可以为空
//                //第三个参数: 增加到数据库表的元素
//                database3.insert("people", "name", values);
                break;
            case R.id.ic_pound:
                Str+="*";
                break;
            case R.id.ic_hash:
                Str+="#";
                break;
            case R.id.del:
                if(Str.length() ==0){
                    break;
                }else {
                   Str = Str.substring(0,Str.length()-1);
                }

                break;

        }
        Te_call.setText(Str);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }
}
