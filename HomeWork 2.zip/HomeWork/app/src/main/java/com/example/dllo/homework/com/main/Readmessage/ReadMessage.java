package com.example.dllo.homework.com.main.Readmessage;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

public class ReadMessage extends Activity {

    MyService.MyIband myIband;
    private ArrayList<ReadBean> arrayList_read;
    private RecyclerView recyclerView;
    private String phonenumber_huode;
    private EditText edit;
    private PopupWindow popupWindow;
    private TextView textView;
    private Button btn_meau_title;
    private MyConnection myConnection;
    private ReadMessageAdpter readMessageAdpter;
    private MyBraccast myBraccast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_read_message);
        edit = (EditText) findViewById(R.id.et_readMessage);

        Intent intentService = new Intent(this, MyService.class);
        startService(intentService);
        myConnection = new MyConnection();
        bindService(intentService, myConnection, BIND_AUTO_CREATE);

        recyclerView = (RecyclerView) findViewById(R.id.rv_read_message);
        arrayList_read = new ArrayList<>();
        jieshou();
        getSmsInPhone();
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);


        myBraccast = new MyBraccast();

        IntentFilter filter = new IntentFilter();
        filter.addAction("zheshiduanxin");
        registerReceiver(myBraccast, filter);


        btn_meau_title = (Button) findViewById(R.id.mean_title);

        btn_meau_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (popupWindow == null || !popupWindow.isShowing()) {

                    initPoP();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(myConnection);
        unregisterReceiver(myBraccast);
    }

    public void initPoP() {
        popupWindow = new PopupWindow(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        View view = LayoutInflater.from(this).inflate(R.layout.pop, null);
        popupWindow.setContentView(view);
        textView = (TextView) view.findViewById(R.id.yanchi);

        textView.setOnClickListener(new View.OnClickListener() {

            private EditText editText;

            @Override
            public void onClick(View v) {

                AlertDialog.Builder yanshi = new AlertDialog.Builder(ReadMessage.this);
                View view1 = LayoutInflater.from(ReadMessage.this).inflate(R.layout.time, null);
                editText = (EditText) view1.findViewById(R.id.et_time);
                yanshi.setTitle("选择延时发送");
                yanshi.setNegativeButton("延时发送(秒)", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (myIband != null) {


                            myIband.test(Integer.parseInt(editText.getText().toString()), phonenumber_huode, edit.getText().toString());

                           // myIband.setData(Integer.parseInt(editText.getText().toString()));

                        }
                    }
                });
                yanshi.setView(view1);
                yanshi.show();

                popupWindow.dismiss();
            }
        });
        popupWindow.showAsDropDown(btn_meau_title, 0, 0);
    }

    public void jieshou() {
        Intent intent = getIntent();
        //获取数据
        phonenumber_huode = intent.getStringExtra("phonenumber");
    }

    public void getSmsInPhone() {
        final String SMS_URI_ALL = "content://sms/";
        final String SMS_URI_INBOX = "content://sms/inbox";
        final String SMS_URI_SEND = "content://sms/sent";
        final String SMS_URI_DRAFT = "content://sms/draft";
        try {
            ContentResolver cr = getContentResolver();
            String[] projection = new String[]{"_id", "address", "person",
                    "body", "date", "type"};
            Uri uri = Uri.parse(SMS_URI_ALL);
            Cursor cur = cr.query(uri, projection, null, null, "date desc");
            while (cur.moveToNext()) {
                String phoneNumber;
                String smsbody;

                int phoneNumberColumn = cur.getColumnIndex("address");
                int smsbodyColumn = cur.getColumnIndex("body");
                int dateColumn = cur.getColumnIndex("date");
                int typeColumn = cur.getColumnIndex("type");

                phoneNumber = cur.getString(phoneNumberColumn);
                smsbody = cur.getString(smsbodyColumn);
                int typeId = cur.getInt(typeColumn);
//                Log.d("ReadMessage", phonenumber_huode);
//                Log.d("ReadMessage", "typeId:" + typeId);
//                Log.d("ReadMessage", phoneNumber);
                if (phonenumber_huode.equals(phoneNumber)) {
                    ReadBean bean = new ReadBean();
                    bean.setPhoneNumber(phoneNumber);
                    bean.setBody(smsbody);
                    bean.setType(typeId);
                    arrayList_read.add(bean);
                }

                readMessageAdpter = new ReadMessageAdpter(this);
                readMessageAdpter.setArrayList(arrayList_read);
                recyclerView.setAdapter(readMessageAdpter);

            }

        } catch (SQLiteException ex) {
            Log.d("ReadMessage", "错误了");
        }

    }

    class MyConnection implements ServiceConnection {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            myIband = (MyService.MyIband) service;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
        }
    }

    private class MyBraccast extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            ReadBean bean = new ReadBean();
            bean.setPhoneNumber(phonenumber_huode);
            bean.setBody(edit.getText().toString());
            bean.setType(2);
            arrayList_read.add(bean);
            readMessageAdpter.setArrayList(arrayList_read);
        }
    }
}
