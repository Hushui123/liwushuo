package com.example.dllo.homework.com.main.shujuku;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by dllo on 16/8/24.
 */
public class MySql extends SQLiteOpenHelper {


    public MySql(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table people(id integer primary key autoincrement,name text,num text,time text)");
        db.execSQL("Create table express(id integer primary key autoincrement,express_no varchar(100),express_name TEXT,express_img BLOB,number TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
