package com.example.dllo.homework.com.main.messge;

/**
 * Created by dllo on 16/8/31.
 */
public interface OnRecyclerItemMessage {
    public void click(int position);
}
