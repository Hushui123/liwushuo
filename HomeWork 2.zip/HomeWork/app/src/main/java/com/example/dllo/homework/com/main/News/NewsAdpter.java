package com.example.dllo.homework.com.main.News;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/31.
 */
public class NewsAdpter extends BaseAdapter {

    public NewsAdpter(Context context) {
        this.context = context;
    }

    Context context;

    public void setArrayList_news(ArrayList<NewsBean> arrayList_news) {
        this.arrayList_news = arrayList_news;
    }

    ArrayList<NewsBean> arrayList_news;

    @Override
    public int getCount() {
        return arrayList_news.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        NewsViewHodler newsViewHodler = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.news_item_top, null);

            newsViewHodler = new NewsViewHodler(convertView);
            convertView.setTag(newsViewHodler);

        } else {
            newsViewHodler = (NewsViewHodler) convertView.getTag();
        }
//        newsViewHodler.img_news.setImageResource(arrayList_news.get(position).getImg());
        newsViewHodler.tv_news.setText(arrayList_news.get(position).getTitle());
        return convertView;
    }

    class NewsViewHodler {

        private final TextView tv_news;
        private final ImageView img_news;

        public NewsViewHodler(View convertView) {
            tv_news = (TextView) convertView.findViewById(R.id.title_news_item);
            img_news = (ImageView) tv_news.findViewById(R.id.img_news);
        }
    }

}
