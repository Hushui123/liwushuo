package com.example.dllo.homework.com.main.person;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;

import com.example.dllo.homework.R;

/**
 * Created by dllo on 16/8/26.
 */
public class MyCirle extends ImageView {
    private boolean isCirCle = false;
    private Bitmap bitmap;

    public MyCirle(Context context) {
        super(context);
    }

    //如果自定义属性的话会走第二 这个方法
    public MyCirle(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.MyCirle);

        isCirCle = array.getBoolean(R.styleable.MyCirle_is_circle, false);
        Log.d("MyCirle", "isCirCle:" + isCirCle);
    }

    public MyCirle(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (isCirCle) {
            BitmapDrawable drawmbale = (BitmapDrawable) getDrawable();
            if (drawmbale != null) {
                bitmap = drawmbale.getBitmap();
                Bitmap circlebitmap = getCiricleBitmap();

                Paint paint = new Paint();
                paint.setAntiAlias(true);

                Rect rect = new Rect(0, 0, circlebitmap.getWidth(),
                        circlebitmap.getHeight());
                canvas.drawBitmap(circlebitmap, rect, rect, paint);
            }
        }
       // super.onDraw(canvas);
    }


    public Bitmap getCiricleBitmap() {

        Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        Canvas canvas = new Canvas(outBitmap);
        canvas.drawCircle(bitmap.getWidth() / 2,
                bitmap.getHeight() / 2, bitmap.getWidth() / 2, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        Rect rect=new Rect(0,0,bitmap.getWidth(),bitmap.getHeight());
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return outBitmap;
    }

}
