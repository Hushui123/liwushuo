package com.example.dllo.homework.com.main.mian;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.Window;
import android.widget.Button;

import com.example.dllo.homework.R;
import com.example.dllo.homework.com.main.News.News;
import com.example.dllo.homework.com.main.bohao.Callrecods;
import com.example.dllo.homework.com.main.messge.Messges;
import com.example.dllo.homework.com.main.person.Person;
import com.example.dllo.homework.com.main.tongxin.TongXin;

import java.util.ArrayList;

public class MainActivity extends FragmentActivity  {

    private TabLayout first_Tb;
    private ViewPager first_Vp;
    private Button btn_meau_title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //去掉主题
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 自定义主题
        //requestWindowFeature(Window.FEATURE_CUSTOM_TITLE);
        setContentView(R.layout.activity_main);
       // getWindow().setFeatureInt(Window.FEATURE_CUSTOM_TITLE,R.layout.title);


        // first_Tb 是TabLayout  first_Vp是ViewPager
        first_Tb = (TabLayout) findViewById(R.id.first_Tb1);
        first_Vp = (ViewPager) findViewById(R.id.first_Vp);

        ArrayList<Fragment> fragments = new ArrayList<>();

        fragments.add(new Callrecods());
        fragments.add(new TongXin());
        fragments.add(new Person());
        fragments.add(new Messges());
        fragments.add(new News());
        // 创建适配器
        Myadpter myadpter = new Myadpter(getSupportFragmentManager(), fragments);
        // 绑定适配器
        first_Vp.setAdapter(myadpter);
        // 将Tablayout与 适配器绑定
        first_Tb.setupWithViewPager(first_Vp);

        // 底部按钮图片变色
        first_Tb.getTabAt(0).setIcon(R.drawable.bohao);
        first_Tb.getTabAt(1).setIcon(R.drawable.tongxinlu);
        first_Tb.getTabAt(2).setIcon(R.drawable.lianxi);
        first_Tb.getTabAt(3).setIcon(R.drawable.messge);
        first_Tb.getTabAt(4).setIcon(R.drawable.bohao);

//        first_Tb.getTabAt(0).setCustomView(R.layout.bohaotu);
//        first_Tb.getTabAt(1).setCustomView(R.layout.tongxintu);
//        first_Tb.getTabAt(2).setCustomView(R.layout.persontu);
//        first_Tb.getTabAt(3).setCustomView(R.layout.messagetu);

    }


}
