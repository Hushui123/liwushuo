package com.example.dllo.homework.com.main.caogaoxiang;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dllo.homework.R;
import com.example.dllo.homework.com.main.messge.MyBean;

import java.util.ArrayList;

/**
 * Created by dllo on 16/9/5.
 */
public class CaoRVAdpter extends RecyclerView.Adapter<CaoRVAdpter.ViewHodler> {

    Context context;
    ArrayList<MyBean> arrayList;

    public void setArrayList(ArrayList<MyBean> arrayList) {
        this.arrayList = arrayList;
    }

    public CaoRVAdpter(Context context) {
        this.context = context;
    }

    @Override
    public CaoRVAdpter.ViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.caoxiang_item, parent, false);
        ViewHodler viewHodler = new ViewHodler(view);

        return viewHodler;
    }

    @Override
    public void onBindViewHolder(CaoRVAdpter.ViewHodler holder, int position) {
        holder.content.setText(arrayList.get(position).getBody());
        holder.num.setText(arrayList.get(position).getNumber());
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class ViewHodler extends RecyclerView.ViewHolder {


        private final TextView num;
        private final TextView content;

        public ViewHodler(View itemView) {
            super(itemView);
            num = (TextView) itemView.findViewById(R.id.caogaoxiang);
            content = (TextView) itemView.findViewById(R.id.caogaoxiang_cantent);

        }
    }
}
