package com.example.dllo.homework.com.main.Readmessage;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.telephony.SmsManager;
import android.util.Log;

/**
 * Created by dllo on 16/9/8.
 */
public class MyService extends Service {
    private MyIband myIband = new MyIband();
    int i = 0;
    String phnome = null;
    String con = null;
    private int k = 0;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return myIband;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("MyService", "oncread");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
 //       new Thread(new Runnable() {
//            @Override
//            public void run() {
//                if (i !=0) {
//                    try {
//                        Thread.sleep(i * 1000);
//
//                        SmsManager manager1 = SmsManager.getDefault();
//                        manager1.sendTextMessage(phnome, null, con, null, null);
//                        Intent intent = new Intent("zheshiduanxin");
//                        sendBroadcast(intent, null);
//
//                    } catch (InterruptedException e) {
//                        e.printStackTrace();
//                    }
//                }
//
//            }
//        }).start();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    class MyIband extends Binder {
        public void test(int j, String num, String content) {
            phnome = num;
            k = j;
            con = content;
            Log.d("MyIband", phnome);
            Log.d("MyIband", con);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(k *1000);
                        Log.d("MyService", "zhege");
                        if (phnome.length()!=0&&con.length()!=0) {
                            SmsManager manager1 = SmsManager.getDefault();
                            manager1.sendTextMessage(phnome, null, con, null, null);

                            Intent intent =new Intent("zheshiduanxin");
                            sendBroadcast(intent,null);

                            Log.d("MyService1", "延迟了"+k+"秒");

                        }


                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

        public int getDate() {

            return i;
        }

        public void setData(int data) {
            i = data;
        }
    }
}
