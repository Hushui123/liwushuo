package com.example.dllo.homework.com.main.Readmessage;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/31.
 */
public class ReadMessageAdpter extends RecyclerView.Adapter {
    public ReadMessageAdpter(Context context) {
        this.context = context;
    }

    Context context;
    ArrayList<ReadBean> arrayList;

    public void setArrayList(ArrayList<ReadBean> arrayList) {
        this.arrayList = arrayList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return arrayList.get(position).getType();

    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case 1:
                View view = LayoutInflater.from(context).inflate(R.layout.item_message_left, parent, false);
                Left_ViewHodler left_viewHodler = new Left_ViewHodler(view);
                return left_viewHodler;
            case 2:
                View view1 = LayoutInflater.from(context).inflate(R.layout.item_message_right, parent, false);
                Right_ViewHodler right_viewHodler = new Right_ViewHodler(view1);
                return right_viewHodler;

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        int type=getItemViewType(position);
        switch (type){
            case 1:
                Left_ViewHodler left_viewHodler= (Left_ViewHodler) holder;
                left_viewHodler.tv_left.setText(arrayList.get(position).getBody());
                break;
            case 2:
                Right_ViewHodler right_viewHodler= (Right_ViewHodler) holder;
                right_viewHodler.tv_right.setText(arrayList.get(position).getBody());
                break;
        }

    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    class Left_ViewHodler extends RecyclerView.ViewHolder {

        TextView tv_left;

        public Left_ViewHodler(View itemView) {
            super(itemView);
            tv_left = (TextView) itemView.findViewById(R.id.tv_left_item_messsage);
        }
    }

    class Right_ViewHodler extends RecyclerView.ViewHolder {
        TextView tv_right;
        public Right_ViewHodler(View itemView) {
            super(itemView);
            tv_right = (TextView) itemView.findViewById(R.id.tv_right_item_message);
        }
    }
}
