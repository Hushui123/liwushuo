package com.example.dllo.homework.com.main.messge;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/30.
 */
public class MyRvAdpter extends RecyclerView.Adapter<MyRvAdpter.ViewHodler> {
    Context context;
    ArrayList<MyBean> myBeen = new ArrayList<>();

    public void setOnRecyclerItemMessage(OnRecyclerItemMessage onRecyclerItemMessage) {
        this.onRecyclerItemMessage = onRecyclerItemMessage;
    }

    OnRecyclerItemMessage onRecyclerItemMessage;
    public void setMyBeen(ArrayList<MyBean> myBeen) {
        this.myBeen = myBeen;
        notifyDataSetChanged();
    }

    public MyRvAdpter(Context context) {
        this.context = context;
    }

    @Override
    public MyRvAdpter.ViewHodler onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.messagetu, parent, false);
        ViewHodler viewHodler = new ViewHodler(view);

        return viewHodler;
    }

    @Override
    public void onBindViewHolder(MyRvAdpter.ViewHodler holder, final int position) {

        holder.body.setText(myBeen.get(position).getBody());
        holder.name.setText(myBeen.get(position).getName());
        holder.time.setText(myBeen.get(position).getTime());
        holder.linearLayout_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onRecyclerItemMessage.click(position);
            }
        });
    }

    @Override
    public int getItemCount() {

        return myBeen.size();

    }

    public class ViewHodler extends RecyclerView.ViewHolder {

        TextView time, name, body;
        LinearLayout linearLayout_message;
        public ViewHodler(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name_number);
            body = (TextView) itemView.findViewById(R.id.body_message);
            time = (TextView) itemView.findViewById(R.id.time_message);
            linearLayout_message = (LinearLayout) itemView.findViewById(R.id.ll_Message);
        }
    }
}
