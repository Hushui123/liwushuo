package com.example.dllo.homework.com.main.messge;

import android.annotation.TargetApi;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RemoteViews;
import android.widget.Toast;

import com.example.dllo.homework.R;
import com.example.dllo.homework.com.main.Readmessage.ReadMessage;
import com.example.dllo.homework.com.main.caogaoxiang.CaoGaoXiang;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by dllo on 16/8/18.
 */
public class Messges extends Fragment {
    private Context context;
    private RecyclerView rv;
    private ArrayList<MyBean> arrayList;
    private MyNoOderBroadcastReiver reiver;
    private MyRvAdpter myRvAdpter;
    private BroadCast receiver1;
    // private MyRvAdpter myRvAdpter;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.messges, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        rv = (RecyclerView) view.findViewById(R.id.rv_message);


        reiver = new MyNoOderBroadcastReiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction("xinxi");
        context.registerReceiver(reiver, filter);
//
//        Intent intent=new Intent("android.permission.RECEIVE_SMS");
//
//
//        context.sendOrderedBroadcast(intent,null);
        receiver1 = new BroadCast();
        IntentFilter hu = new IntentFilter();
        hu.addAction("android.provider.Telephony.SMS_RECEIVED");
        context.registerReceiver(receiver1, hu);
        //getSmsInPhone();
        gaijing();
        chongfu();

        myRvAdpter = new MyRvAdpter(context);
        myRvAdpter.setMyBeen(arrayList);
        rv.setAdapter(myRvAdpter);

        final LinearLayoutManager manager = new LinearLayoutManager(context);
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        rv.setLayoutManager(manager);

        myRvAdpter.setOnRecyclerItemMessage(new OnRecyclerItemMessage() {
            @Override
            public void click(int position) {
                Intent intent = new Intent(context, ReadMessage.class);
                intent.putExtra("phonenumber", arrayList.get(position).getNumber());
                Log.d("Messges", arrayList.get(position).getNumber());
                startActivity(intent);
            }
        });


        Button btn_meau_title = (Button) view.findViewById(R.id.mean_title);
        btn_meau_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("MainActivity", "nihao");
                AlertDialog.Builder mean = new AlertDialog.Builder(context);
                mean.setTitle("发送短信");

                View view = LayoutInflater.from(context).inflate(R.layout.mean_title, null);
                final EditText number = (EditText) view.findViewById(R.id.edi_number);
                final EditText content = (EditText) view.findViewById(R.id.edi_content);

                mean.setNegativeButton("发送", new DialogInterface.OnClickListener() {

                    private String content1;
                    private String num;

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        num = number.getText().toString();
                        content1 = content.getText().toString();
                        SmsManager manager1 = SmsManager.getDefault();
                        if (num.length() == 0) {
                            Toast.makeText(context, "电话不能为空", Toast.LENGTH_SHORT).show();
                        } else if (content1.length() == 0) {
                            Toast.makeText(context, "内容不能为空", Toast.LENGTH_SHORT).show();
                        } else {
                            manager1.sendTextMessage(num, null, content1, null, null);

                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            Intent intent = new Intent("xinxi");

                            context.sendOrderedBroadcast(intent, null);
                        }


                    }
                })
                        .setPositiveButton("退出", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(context, "信息发送取消", Toast.LENGTH_SHORT).show();

                            }
                        })

                        .setNeutralButton("保存至草稿箱", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent in = new Intent(context, CaoGaoXiang.class);
                                in.putExtra("num", number.getText().toString());
                                in.putExtra("content", content.getText().toString());
                                startActivity(in);
                            }
                        });
                mean.setView(view);
                mean.show();

            }

        });


    }

    public void getSmsInPhone() {
        final String SMS_URI_ALL = "content://sms/";
        final String SMS_URI_INBOX = "content://sms/inbox";
        final String SMS_URI_SEND = "content://sms/sent";
        final String SMS_URI_DRAFT = "content://sms/draft";


        try {
            ContentResolver cr = context.getContentResolver();
            String[] projection = new String[]{"_id", "address", "person",
                    "body", "date", "type"};
            Uri uri = Uri.parse(SMS_URI_ALL);
            Cursor cur = cr.query(uri, projection, null, null, "date desc");
            while (cur.moveToNext()) {
                String name;
                String phoneNumber;
                String smsbody;
                String date;
                String type;

                int nameColumn = cur.getColumnIndex("person");
                int phoneNumberColumn = cur.getColumnIndex("address");
                int smsbodyColumn = cur.getColumnIndex("body");
                int dateColumn = cur.getColumnIndex("date");
                int typeColumn = cur.getColumnIndex("type");
                //  name = names.getString(names.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                MyBean bean = new MyBean();
                name = cur.getString(nameColumn);
                phoneNumber = cur.getString(phoneNumberColumn);
                smsbody = cur.getString(smsbodyColumn);

                SimpleDateFormat dateFormat = new SimpleDateFormat(
                        "yyyy-MM-dd hh:mm:ss");
                Date d = new Date(Long.parseLong(cur.getString(dateColumn)));
                date = dateFormat.format(d);

                int typeId = cur.getInt(typeColumn);
                if (typeId == 1) {
                    type = "接收";
                } else if (typeId == 2) {
                    type = "发送";
                } else {
                    type = "";
                }
                // Log.d("Messges", name);
                if (name == null) {
                    bean.setName(phoneNumber);
                } else {
                    bean.setName(name);
                }
                bean.setNumber(phoneNumber);
                bean.setBody(smsbody);
                bean.setTime(date);

                arrayList.add(bean);

                MyRvAdpter myRvAdpter = new MyRvAdpter(context);
                myRvAdpter.setMyBeen(arrayList);
                rv.setAdapter(myRvAdpter);
            }

        } catch (SQLiteException ex) {
            Log.d("SQLiteException in getSmsInPhone", ex.getMessage());
        }

    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void gaijing() {
        arrayList = new ArrayList<>();
        ContentResolver resolver = context.getContentResolver();
        Cursor cursor = resolver.query(Telephony.Sms.CONTENT_URI, null, null, null, null);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = null;
                String id = cursor.getString(cursor.getColumnIndex(Telephony.Sms.PERSON));
                if (id != null) {
                    Cursor names = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME},
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?",
                            new String[]{id}, null);
                    names.moveToNext();
                    name = names.getString(names.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                } else {
                    name = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));

                }
                String content = cursor.getString(cursor.getColumnIndex(Telephony.Sms.BODY));
                String phoneNumber = cursor.getString(cursor.getColumnIndex(Telephony.Sms.ADDRESS));
                String date = cursor.getString(cursor.getColumnIndex(Telephony.Sms.DATE));
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss.S");
                String time = formatter.format(Long.valueOf(date));

                MyBean bean = new MyBean();
                bean.setNumber(phoneNumber);
                bean.setName(name);
                bean.setBody(content);
                bean.setTime(time);
                arrayList.add(bean);

            }
        }


    }

    public void chongfu() {
        for (int i = 0; i < arrayList.size() - 1; i++) {

            for (int j = arrayList.size() - 1; j > i; j--) {
                if (arrayList.get(j).getNumber().equals(arrayList.get(i).getNumber())) {
                    arrayList.remove(j);
                }
            }

        }

    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        context.unregisterReceiver(reiver);
        getContext().unregisterReceiver(receiver1);
    }


    private class MyNoOderBroadcastReiver extends BroadcastReceiver {
        @Override
        public void onReceive(final Context context, Intent intent) {
            Log.d("MyNoOderBroadcastReiver", "hahahha");
            // MyBean bean = new MyBean();


            gaijing();
            chongfu();

            //      MyRvAdpter myRvAdpter = new MyRvAdpter(context);
            myRvAdpter.setMyBeen(arrayList);
            //       rv.setAdapter(myRvAdpter);

//            final LinearLayoutManager manager = new LinearLayoutManager(context);
//            manager.setOrientation(LinearLayoutManager.VERTICAL);
//            rv.setLayoutManager(manager);
//
//            myRvAdpter.setOnRecyclerItemMessage(new OnRecyclerItemMessage() {
//                @Override
//                public void click(int position) {
//                    Intent intent = new Intent(context, ReadMessage.class);
//                    intent.putExtra("phonenumber", arrayList.get(position).getNumber());
//                    Log.d("Messges", arrayList.get(position).getNumber());
//                    startActivity(intent);
//                }
//            });
        }
    }


    private class BroadCast extends BroadcastReceiver {

        @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
        @Override
        public void onReceive(Context context, Intent intent) {
            Object[] pduses = (Object[]) intent.getExtras().get("pdus");
            Log.d("BroadCast", "lalalalla");
            for (Object pdus : pduses) {
                byte[] pdusmessage = (byte[]) pdus;
                SmsMessage sms = SmsMessage.createFromPdu(pdusmessage);
                String mobile = sms.getOriginatingAddress();//发送短信的手机号码
                String content = sms.getMessageBody(); //短信内容
                Date date = new Date(sms.getTimestampMillis());
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String time = format.format(date);  //得到发送时间

                Log.d("BroadCast", time);

                NotificationManager manger = (NotificationManager) getContext().getSystemService(Context.NOTIFICATION_SERVICE);
                Notification.Builder budler = new Notification.Builder(getContext());
                budler.setSmallIcon(R.mipmap.ic_launcher);
                budler.setTicker("有一条新消息");
                // 创建一个RemotViews

                RemoteViews remoteViews = new RemoteViews(getContext().getPackageName(), R.layout.notify_custem);
                remoteViews.setTextViewText(R.id.body_tv, content);
                remoteViews.setTextViewText(R.id.num_messge, mobile);
                remoteViews.setTextViewText(R.id.tiem_tv, time);


//                MyBean bean = new MyBean();
//                bean.setBody(content);
//                bean.setNumber(mobile);
//                bean.setTime(time);
//                arrayList.add(bean);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                gaijing();
                chongfu();
                //      MyRvAdpter myRvAdpter = new MyRvAdpter(context);
                myRvAdpter.setMyBeen(arrayList);
                Log.d("BroadCast", "lalalaaaaaaa");
                rv.setAdapter(myRvAdpter);

                Intent intent1 = new Intent(context, ReadMessage.class);
                intent1.putExtra("phonenumber", mobile);
                PendingIntent intent2 = PendingIntent.getActivity(context, 100, intent1, PendingIntent.FLAG_UPDATE_CURRENT);
                budler.setContentIntent(intent2);

                budler.setContent(remoteViews);
                Notification nofi = budler.build();
                manger.notify(150, nofi);


            }
        }
    }


}
