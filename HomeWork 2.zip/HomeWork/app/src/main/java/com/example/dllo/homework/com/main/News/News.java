package com.example.dllo.homework.com.main.News;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/31.
 */
public class News extends Fragment {

    private ListView lv_news;
    private Context context;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.news_item,null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        lv_news = (ListView) view.findViewById(R.id.lv_news);

        ArrayList<NewsBean> beenlist =new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            NewsBean bean=new NewsBean();
            bean.setImg(R.mipmap.ic_launcher);
            bean.setTitle("我爱中国");
            beenlist.add(bean);
        }

        NewsAdpter adpter=new NewsAdpter(context);
        adpter.setArrayList_news(beenlist);
        lv_news.setAdapter(adpter);

    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }
}
