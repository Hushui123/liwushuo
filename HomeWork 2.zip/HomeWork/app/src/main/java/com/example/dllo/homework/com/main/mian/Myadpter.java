package com.example.dllo.homework.com.main.mian;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/18.
 */
public class Myadpter extends FragmentPagerAdapter{

    ArrayList<Fragment> fragments;
    // 构造Fragment集合进行传参
    ArrayList<String> title=new ArrayList<>();
    public Myadpter(FragmentManager fm, ArrayList<Fragment> fragments) {
        super(fm);



        this.fragments=fragments;
        this.title.add("拨号");
        this.title.add("通信记录");
        this.title.add("联系人");
        this.title.add("信息");
        this.title.add("新闻");
    }

    //4 在getitem getcount 方法中返回对应的集合XXX
    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments==null?0:fragments.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return title.get(position);
    }
}
