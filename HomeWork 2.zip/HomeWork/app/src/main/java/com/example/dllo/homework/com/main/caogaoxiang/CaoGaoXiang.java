package com.example.dllo.homework.com.main.caogaoxiang;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.dllo.homework.R;
import com.example.dllo.homework.com.main.messge.MyBean;

import java.util.ArrayList;

public class CaoGaoXiang extends Activity {

    private String num_1;
    private String content_1;
    private RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cao_gao_xiang);
        rv = (RecyclerView) findViewById(R.id.rv_caogaoxiang);

        Intent intent = getIntent();
        num_1 = intent.getStringExtra("num");
        content_1 = intent.getStringExtra("content");
        ArrayList<MyBean> list = new ArrayList<>();
        MyBean bean = new MyBean();
        bean.setNumber(num_1);
        bean.setBody(content_1);

        list.add(bean);

        LinearLayoutManager manager = new LinearLayoutManager(this);
        rv.setLayoutManager(manager);
        SharedPreferences sp = getSharedPreferences("count", MODE_PRIVATE);

        SharedPreferences.Editor spET = sp.edit();
        spET.putString(num_1, num_1);
        spET.putString(content_1, content_1);
        spET.commit();
        //SharedPreferences getSp = getSharedPreferences("count", MODE_PRIVATE);
      //  while (getSp.getString(num_1, "bucuzai") != null) {

      //  }

        CaoRVAdpter adpter = new CaoRVAdpter(this);
        adpter.setArrayList(list);
        rv.setAdapter(adpter);
//
//        num.setText(num_1);
//        content.setText(content_1);


    }
}
