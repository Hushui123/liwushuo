package com.example.dllo.homework.com.main.tongxin;

/**
 * Created by dllo on 16/8/19.
 */
public class MyBean {
    String name;
    String num;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    String time;
    public boolean isPandun() {
        return pandun;
    }

    public void setPandun(boolean pandun) {
        this.pandun = pandun;
    }

    boolean pandun =false;
    public boolean isCheckBox() {
        return CheckBox;
    }

    public void setCheckBox(boolean checkBox) {
        CheckBox = checkBox;
    }

    boolean CheckBox = false;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }


}
