package com.example.dllo.homework.com.main.Circular;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.ImageView;

import com.example.dllo.homework.R;

/**
 * Created by dllo on 16/8/26.
 */
public class Message extends ImageView{
    private boolean isCircular = false;
    private Bitmap bitmap;

    public Message(Context context) {
        super(context);
    }
    //如果自定义属性的话,会执行这个方法
    public Message(Context context, AttributeSet attrs) {
        super(context, attrs);
        //通过obtainStyledAttributes的方法 取出attrs.xml文件中对应的 MyCircleImage的属性
        TypedArray array=context.obtainStyledAttributes(attrs,R.styleable.Message);

        isCircular=array.getBoolean(R.styleable.Message_is_circuar,false);
        Log.d("Message", "isCircular:" + isCircular);
    }

    public Message(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //super.onDraw(canvas);
        if(isCircular){
            //在这段代码里画圆
            //获取到src设置的图片
            BitmapDrawable drawmable= (BitmapDrawable) getDrawable();
            if(drawmable !=null){
                bitmap = drawmable.getBitmap();
                Bitmap circularBitmap=getCircularBitmap();
                Paint paint=new Paint();
                paint.setAntiAlias(true);

                Rect rect =new Rect(0,0,circularBitmap.getWidth(),circularBitmap.getHeight());
                canvas.drawBitmap(circularBitmap,rect,rect,paint);
            }

        }
    }

    public Bitmap getCircularBitmap() {
        Bitmap outBitmap = Bitmap.createBitmap(bitmap.getWidth(),bitmap.getHeight(),Bitmap.Config.ARGB_8888);
        Paint paint =new Paint();
        paint.setAntiAlias(true);
        Canvas canvas=new Canvas(outBitmap);
        canvas.drawCircle(bitmap.getWidth()/2,bitmap.getHeight()/2,bitmap.getWidth(),paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));

        Rect rect=new Rect(0,0,bitmap.getWidth(),bitmap.getHeight());
        canvas.drawBitmap(bitmap,rect,rect,paint);
        return outBitmap;
    }
}
