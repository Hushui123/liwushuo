package com.example.dllo.homework.com.main.tongxin;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.CallLog;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;

import com.example.dllo.homework.R;
import com.example.dllo.homework.com.main.shujuku.MySql;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by dllo on 16/8/18.
 */
public class TongXin extends Fragment {

    private ListView myLv;
    private TxAdpet madpt;
    private CheckBox checkBox;

    private SQLiteDatabase database;
    private SQLiteDatabase database1;
    private ArrayList<MyBean> arrayList;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        return inflater.inflate(R.layout.tongxintu, null);
    }

    private Context context;
    private Button btn;

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        myLv = (ListView) view.findViewById(R.id.lv_myListview);
        btn = (Button) view.findViewById(R.id.btn);

        checkBox = (CheckBox) view.findViewById(R.id.cb);


        MySql mySql = new MySql(context, "mybean.db", null, 1);
        database = mySql.getWritableDatabase();
        // database1 = context.openOrCreateDatabase("mybean.db", Context.MODE_PRIVATE, null);
        // database = this.ope("lanou.db",MODE_PRIVATE,null);

        arrayList = new ArrayList<>();
        database.delete("people", null, null);
        chaxun();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < arrayList.size(); i++) {

                    if (arrayList.get(i).isCheckBox() == true) {

                        // 删除系统电话号
                        ContentResolver resolver = context.getContentResolver();
                        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                            // TODO: Consider calling
                            //    ActivityCompat#requestPermissions
                            // here to request the missing permissions, and then overriding
                            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                            //                                          int[] grantResults)
                            // to handle the case where the user grants the permission. See the documentation
                            // for ActivityCompat#requestPermissions for more details.
                            return;
                        }
                        resolver.delete(CallLog.Calls.CONTENT_URI, CallLog.Calls.NUMBER + "=?", new String[]{arrayList.get(i).getNum()});

                        //  database1.delete("people", "time=?", new String[]{arrayList.get(i).getTime()});
                        madpt.deleItem(i);
                        i--;
                    }

                }
            }
        });
        myLv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                Log.d("TongXin", "arrayList.size():" + position);
                madpt.show();
                return true;
            }
        });
    }

    public void dele() {
        ArrayList<String> dele = new ArrayList<>();
        ContentResolver resolver = context.getContentResolver();
        long str_date = 0;
        for (int i = 0; i < arrayList.size(); i++) {
            try {
                SimpleDateFormat format = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss.S");
                Log.d("TongXin", arrayList.get(i).getTime());
                Date date1 = format.parse(arrayList.get(i).getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }
            dele.add(str_date + "");
        }


        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        for (int i = 0; i < arrayList.size(); i++) {
            Log.d("TongXin", "arrayList.size():" + arrayList.size());
            resolver.delete(CallLog.Calls.CONTENT_URI, CallLog.Calls.DATE + "=?", new String[]{arrayList.get(i).getTime()});
        }
    }

    public void chaxun() {
        // 获得ContentResolver的对象
        ContentResolver resolver = context.getContentResolver();

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Cursor cursor = resolver.query(CallLog.Calls.CONTENT_URI, null, null, null, null);
        if (cursor != null) {
//            cursor.moveToFirst();查询结果一次出现的位置
            while (cursor.moveToNext()) {
                //ContentValues values = new ContentValues();
                String date = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DATE));
                String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                String name;
                if (cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME)) != null) {
                    name = cursor.getString(cursor.getColumnIndex(CallLog.Calls.CACHED_NAME));
                    //    values.put("name", name);
                } else {
                    name = "未知身份";
                }
                SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss");
                String time = format.format(Long.valueOf(date));//获取当前时间
//                long turent = System.currentTimeMillis();
//                values.put("name", name);
//                values.put("time", time);
//                values.put("num", number);
//                //第一个参数:表名
//                //第二个参数: 代表某一列可以为空
//                //第三个参数: 增加到数据库表的元素
//                database3.insert("people", "name", values);
                MyBean myBean = new MyBean();

                myBean.setName(name);
                myBean.setNum(number);
                myBean.setTime(time);
                arrayList.add(myBean);
            }
        }
        madpt = new TxAdpet(context);
        madpt.setArrayList(arrayList);
        myLv.setAdapter(madpt);
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        Log.d("TongXin", "isVisibleToUser:" + isVisibleToUser);
        if (isVisible()) {
            database.delete("people", null, null);
            arrayList.clear();
            chaxun();
        } else {

        }


    }

    // 承接上下文
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }


}
