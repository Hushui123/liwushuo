package com.example.dllo.homework.com.main.Xianchengchi;

import android.util.Log;

import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by dllo on 16/9/2.
 */
public class MyThread {
    private final ThreadPoolExecutor poolExecutor;
    private static MyThread myThread;

    public ThreadPoolExecutor getPoolExecutor() {


        return poolExecutor;
    }

   public static MyThread getInstence(){
       if (myThread == null) {
           myThread = new MyThread();
           synchronized (MyThread.class){
               if (myThread == null) {
                   myThread=new MyThread();
               }
           }
       }
       return myThread;
   }

    public MyThread() {
        int CPUCore = Runtime.getRuntime().availableProcessors();
        Log.d("MyThread", "CPUCore:" + CPUCore);
        poolExecutor = new ThreadPoolExecutor(CPUCore+1,
                CPUCore*2+1,60l, TimeUnit.SECONDS,new LinkedBlockingDeque<Runnable>());
    }
}
