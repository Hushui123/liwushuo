package com.example.dllo.homework.com.main.person;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.dllo.homework.R;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by dllo on 16/8/18.
 */
public class Person extends Fragment implements AdapterView.OnItemClickListener {

    private ListView listView;
    private Context context;
    private Cursor canvas;
    private ArrayList<MyPerson_bean> myPerson_been;
   private SQLiteDatabase database3;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.person, null);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        listView = (ListView) view.findViewById(R.id.person_lv);
        myPerson_been = new ArrayList<>();
        jiashuju();
       database3.delete("express", null, null);
        phto();

        listView.setOnItemClickListener(this);
    }


    // 将虚拟机中的联系人姓名 电话号 头像读出来 ,并存储在app数据库中
    public void phto() {
        ContentResolver resolver = getActivity().getContentResolver();
        Cursor cursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

     //   database3 = context.openOrCreateDatabase("mybean.db", Context.MODE_PRIVATE, null);
     //   ContentValues values = new ContentValues();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                Long id = cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_ID));
                long contactid = cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
                Bitmap contactPhoto = null;

                //photoid 大于0 表示联系人有头像 如果没有给此人设置头像则给他一个默认的
                if (id > 0) {
                    Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactid);
                    InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(resolver, uri);
                    contactPhoto = BitmapFactory.decodeStream(input);
                } else {
                    contactPhoto = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
                }


                MyPerson_bean bean = new MyPerson_bean();
                bean.setImg(contactPhoto);
                bean.setName(name);
                bean.setNumber(number);
                Log.d("Person", number);
                myPerson_been.add(bean);
//
//                //  将图片存储数据库
//                final ByteArrayOutputStream os = new ByteArrayOutputStream();
//                contactPhoto.compress(Bitmap.CompressFormat.PNG, 100, os);
//                values.put("express_img", os.toByteArray());
//                values.put("express_name", name);
//                values.put("number", number);
//                database3.insert("express", "express_img", values);
                MyPerson_Adpter adpter = new MyPerson_Adpter(myPerson_been, context);
                listView.setAdapter(adpter);
            }
        }

    }

    // 初始化数据,防止第一次删除数据库发生空指针异常
    public void jiashuju() {
        ContentResolver resolver = getActivity().getContentResolver();
        Cursor cursor = resolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        database3 = context.openOrCreateDatabase("mybean.db", Context.MODE_PRIVATE, null);
        ContentValues values = new ContentValues();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                Long id = cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_ID));
                long contactid = cursor.getLong(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID));
                Bitmap contactPhoto = null;

                //photoid 大于0 表示联系人有头像 如果没有给此人设置头像则给他一个默认的
                if (id > 0) {
                    Uri uri = ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, contactid);
                    InputStream input = ContactsContract.Contacts.openContactPhotoInputStream(resolver, uri);
                    contactPhoto = BitmapFactory.decodeStream(input);
                } else {
                    contactPhoto = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);
                }


                final ByteArrayOutputStream os = new ByteArrayOutputStream();
                contactPhoto.compress(Bitmap.CompressFormat.PNG, 100, os);
                values.put("express_img", os.toByteArray());
                Log.d("Person", "os.toByteArray():" + os.toByteArray());
                values.put("express_name", name);
                values.put("number", number);
                Log.d("Person", name);
                database3.insert("express", "name", values);
            }
        }
    }

    // 链接上下文,放在frgment
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        this.context = context;
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent hiddenI = new Intent(Intent.ACTION_CALL);
        // 设置data数据
        // 访问拨号界面
        Uri dataU = Uri.parse("tel:" + myPerson_been.get(position).getNumber());
        hiddenI.setData(dataU);
        startActivity(hiddenI);
    }
}
