package com.example.dllo.homework.com.main.person;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;

/**
 * Created by dllo on 16/8/26.
 */
public class MyPerson_Adpter extends BaseAdapter {

    Context context;
    ArrayList<MyPerson_bean> myPerson_been;

    public MyPerson_Adpter(ArrayList<MyPerson_bean> myPerson_been, Context context) {
        this.myPerson_been = myPerson_been;
        this.context = context;
    }

    @Override
    public int getCount() {
        return myPerson_been.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHodle viewHodle = null;
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.persontu, null);
            viewHodle = new ViewHodle(convertView);
            convertView.setTag(viewHodle);
        } else {
            viewHodle = (ViewHodle) convertView.getTag();
        }
        // viewHodle.person_circule.setImageResource(myPerson_been.get(position).getImg());
        viewHodle.img.setImageBitmap(myPerson_been.get(position).getImg());
        viewHodle.textView.setText(myPerson_been.get(position).getName());
        return convertView;
    }

    class ViewHodle {
        private final TextView textView;
        private final MyCirle img;

        public ViewHodle(View convertView) {

            textView = (TextView) convertView.findViewById(R.id.name_person_tv);
            img = (MyCirle) convertView.findViewById(R.id.myCirle);
        }
    }
}
