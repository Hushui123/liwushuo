package com.example.dllo.homework.com.main.tongxin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import com.example.dllo.homework.R;

import java.util.ArrayList;


/**
 * Created by dllo on 16/8/19.
 */
public class TxAdpet extends BaseAdapter {


    private Context mcontext;
    // 构造集合传递数据
    ArrayList<MyBean> arrayList;
//

    public TxAdpet(Context mcontext) {
        this.mcontext = mcontext;
    }


    public void setArrayList(ArrayList<MyBean> arrayList) {
        this.arrayList = arrayList;
    }

    public ArrayList<MyBean> getArrayList() {
        return arrayList;
    }

    public void deleItem(int postion) {
        arrayList.remove(postion);
       // database1.delete("people","name=?",new String[]{"小泽老师"});

        for (int i = 0; i < arrayList.size(); i++) {
            arrayList.get(i).setPandun(false);
        }
        notifyDataSetChanged();
    }

    public void addItem(int postion) {

        MyBean myBean = new MyBean();
        myBean.setName("dada");
        myBean.setNum("12");
        arrayList.add(0, myBean);
        //show();
        notifyDataSetChanged();


    }

    // 得到数据的个数
    @Override
    public int getCount() {
        return arrayList == null ? 0 : arrayList.size();
    }

    //得到某一条数据内容
    @Override
    public Object getItem(int position) {
        return arrayList.get(position);
    }

    //得到某一条数据的id
    @Override
    public long getItemId(int position) {
        return position;
    }

    ViewHodler viewPage = null;

    //给视图赋值
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {


        if (convertView == null) {
            convertView = LayoutInflater.from(mcontext).inflate(R.layout.tongxin, null);
            viewPage = new ViewHodler(convertView);
            convertView.setTag(viewPage);
        } else {
            viewPage = (ViewHodler) convertView.getTag();
        }
        viewPage.name.setText(arrayList.get(position).getName());
        viewPage.num.setText(arrayList.get(position).getNum() + "");
        viewPage.time.setText(arrayList.get(position).getTime());

        if (arrayList.get(position).isPandun() == true) {
            viewPage.ch.setVisibility(View.VISIBLE);
        } else {
            viewPage.ch.setVisibility(View.INVISIBLE);
        }
        viewPage.ch.setChecked(arrayList.get(position).isCheckBox());


        viewPage.ch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox cb = (CheckBox) v;
                arrayList.get(position).setCheckBox(cb.isChecked());
            }
        });

        return convertView;
    }


    public void show() {

        for (int i = 0; i < arrayList.size(); i++) {
            arrayList.get(i).setPandun(true);
        }
        notifyDataSetChanged();

    }

    class ViewHodler {
        private TextView name, num;
        private TextView time;
        private CheckBox ch;


        public ViewHodler(View converView) {
            name = (TextView) converView.findViewById(R.id.name);
            num = (TextView) converView.findViewById(R.id.num);
            time = (TextView) converView.findViewById(R.id.edi_time);
            ch = (CheckBox) converView.findViewById(R.id.cb);
//            SimpleDateFormat formatter = new SimpleDateFormat("yyyy年MM月dd日    HH:mm:ss     ");
//            Date curDate = new Date(System.currentTimeMillis());//获取当前时间
//            String str = formatter.format(curDate);
//            time.setText(str);
        }


    }


}

